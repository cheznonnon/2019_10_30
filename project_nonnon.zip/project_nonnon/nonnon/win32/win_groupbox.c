// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//	n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS,  "", &hgui );
//
//	[ WndProc() ]
//
//	n_win_group_proc( ..., hgui )




#ifndef _H_NONNON_WIN32_WIN_GROUPBOX
#define _H_NONNON_WIN32_WIN_GROUPBOX




#include "./gdi/doublebuffer.c"

#include "./win.c"

#include "./uxtheme.c"




#define N_WIN_GROUPBOX_TEXT_OFFSET ( 7 )




// internal
void
n_win_group_draw( HWND hgui, HDC hdc_override, RECT *rect )
{

	s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	HDC hdc;
hdc_override = NULL;
	if ( hdc_override == NULL )
	{
		hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );
	} else {
		hdc = hdc_override;
	}


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, hgui, L"BUTTON" );


	COLORREF color_bg = n_win_darkmode_systemcolor( COLOR_BTNFACE );
	COLORREF color_fg = n_win_darkmode_systemcolor( COLOR_BTNTEXT );

	n_win_box( hgui, hdc, rect, color_bg );


	n_posix_char *text = n_win_text_new( hgui );

	s32 text_sy = 0; n_win_stdsize_text( hgui, text, NULL, &text_sy );
	s32 half_sy = text_sy / 2;

	RECT r;
	if ( false == n_string_is_empty( text ) )
	{
		n_win_rect_set( &r, x, y + half_sy, sx, sy - half_sy );
	} else {
		n_win_rect_set( &r, x, y, sx, sy );
	}

	if ( uxtheme.onoff )
	{

		int part  = BP_GROUPBOX;
		int state = GBS_NORMAL;

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &r, NULL );

	} else {

		DrawEdge( hdc, &r, EDGE_ETCHED, BF_RECT );

	}


	{

		SetBkColor  ( hdc, color_bg );
		SetTextColor( hdc, color_fg );

		s32 scale  = n_win_dpi( hgui ) / 96;
		s32 offset = N_WIN_GROUPBOX_TEXT_OFFSET * scale;

		TextOut( hdc, x + offset, y, text, n_posix_strlen( text ) );

	}

	n_string_free( text );


	n_uxtheme_exit( &uxtheme, hgui );


	if ( hdc_override == NULL )
	{
		n_gdi_doublebuffer_simple_exit();
	} else {
		//
	}


	return;
}

void
n_win_group_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		n_win_group_draw( hgui, di->hDC, &di->rcItem );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_GROUPBOX


/*


#include "../project/macro.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :


		n_project_darkmode();
		//n_win_darkmode_onoff = true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "Nonnon", &hgui );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_stdfont_init( &hgui, 1 );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );
		n_win_move( hgui, 20,20,100,100, true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		n_win_stdfont_exit( &hgui, 1 );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_group_proc( hwnd,msg,wparam,lparam, hgui );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

*/

