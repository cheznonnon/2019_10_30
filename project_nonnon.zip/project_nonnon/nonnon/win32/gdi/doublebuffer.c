// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Ownerdrawn Control ]
//
//	use at WM_DRAWITEM
//
//	[ Standard Controls ]
//
//	use with WM_PRINTCLIENT
//
//	+ this message is important under Desktop Window Manager
//
//	[ Upside Down ]
//
//	you can use two way
//
//	+ 1 : set "sy" minus value
//	+ 2 : set ".upsidedown" true




#ifndef _H_NONNON_WIN32_GDI_DOUBLEBUFFER
#define _H_NONNON_WIN32_GDI_DOUBLEBUFFER




#include "../../neutral/bmp/all.c"


#include "../win/_debug.c"
#include "../win/bitmap.c"
#include "../win/color.c"
#include "../win/font.c"


#include "./dibsection.c"




typedef struct {

	HWND    hgui;
	HDC     hdc;
	HDC     hdc_compat;
	int     bpp;
	s32     sx;
	s32     sy;
	HBITMAP hbmp;
	HBITMAP hbmp_old;
	n_bmp   bmp;
	bool    upsidedown;
	bool    hdc_release;

} n_gdi_doublebuffer;

#define n_gdi_doublebuffer_zero( p ) n_memory_zero( p, sizeof( n_gdi_doublebuffer ) )




static n_gdi_doublebuffer n_gdi_doublebuffer_instance;

#define n_gdi_doublebuffer_simple_init( hgui, sx, sy ) n_gdi_doublebuffer_init( &n_gdi_doublebuffer_instance, hgui, NULL, sx, sy )
#define n_gdi_doublebuffer_simple_exit(              ) n_gdi_doublebuffer_exit( &n_gdi_doublebuffer_instance                     )
#define n_gdi_doublebuffer_simple_fill( colorref     ) n_gdi_doublebuffer_fill( &n_gdi_doublebuffer_instance,           colorref )

void
n_gdi_doublebuffer_simple_zero( void )
{

	// [!] : for gcc warning

	n_gdi_doublebuffer_zero( &n_gdi_doublebuffer_instance );

	return;
}

#define n_gdi_doublebuffer_simple_cleanup() n_gdi_doublebuffer_cleanup( &n_gdi_doublebuffer_instance )

#define n_gdi_doublebuffer_simple_visible() n_gdi_doublebuffer_visible( &n_gdi_doublebuffer_instance )

#define n_gdi_doublebuffer_simple_exit_partial( x,y,sx,sy ) n_gdi_doublebuffer_exit_partial( &n_gdi_doublebuffer_instance, x,y,sx,sy )




bool
n_gdi_doublebuffer_dwm_is_on( void )
{

	bool ret = false;


	// [!] : for compatibility layer support

	if ( false == n_sysinfo_version_vista_or_later() ) { return ret; }


	HMODULE hmod = LoadLibrary( n_posix_literal( "dwmapi.dll" ) );
	if ( hmod == NULL ) { return ret; }

	FARPROC func = GetProcAddress( hmod, "DwmIsCompositionEnabled" );
	if ( func != NULL )
	{
		if ( S_OK != func( &ret ) ) { ret = false; }
	}

	FreeLibrary( hmod );


	return ret;
}

HDC
n_gdi_doublebuffer_init( n_gdi_doublebuffer *p, HWND hgui, HDC hdc, s32 sx, s32 sy )
{

	// [!] : use returned HDC to draw


	// [!] : race condition : prevent GDI handle leak

	if ( p->hdc != NULL ) { return p->hdc_compat; }


	// Init

	n_gdi_doublebuffer_zero( p );

	if ( hdc == NULL )
	{
		hdc = GetDC( hgui );
		p->hdc_release =  true;
	} else {
		p->hdc_release = false;
	}

	p->hgui       = hgui;
	p->hdc        = hdc;
	p->hdc_compat = CreateCompatibleDC( p->hdc );
	p->bpp        = GetDeviceCaps( p->hdc, BITSPIXEL );
	p->sx         = n_posix_max_s32( 1, abs( sx ) );
	p->sy         = n_posix_max_s32( 1, abs( sy ) );

	SelectObject( p->hdc_compat, n_win_font_get( hgui ) );


	int upsidedown = 1; if ( sy < 0 ) { upsidedown = -1; }

	if ( p->bpp == 32 )
	{

		n_gdi_dibsection_zero( &p->hbmp, &p->bmp );
		n_gdi_dibsection_init( &p->hbmp, &p->bmp, p->hgui, p->hdc_compat, p->sx, p->sy * upsidedown );

	} else {

		p->hbmp = CreateCompatibleBitmap( p->hdc, p->sx, p->sy * upsidedown );

	}

	p->hbmp_old = SelectObject( p->hdc_compat, p->hbmp );


	return p->hdc_compat;
}

void
n_gdi_doublebuffer_cleanup( n_gdi_doublebuffer *p )
{

	SelectObject( p->hdc_compat, p->hbmp_old );

	if ( p->bpp == 32 )
	{

		n_gdi_dibsection_exit( &p->hbmp, &p->bmp );

	} else {

		n_win_bitmap_exit( p->hbmp );

	}

	DeleteDC( p->hdc_compat );

	if ( p->hdc_release )
	{
		ReleaseDC( p->hgui, p->hdc );
	}


	n_gdi_doublebuffer_zero( p );


	return;
}

#define n_gdi_doublebuffer_presync(  p ) n_gdi_doublebuffer_sync_partial( p, 0,0,(p)->sx,(p)->sy,  true )
#define n_gdi_doublebuffer_postsync( p ) n_gdi_doublebuffer_sync_partial( p, 0,0,(p)->sx,(p)->sy, false )

void
n_gdi_doublebuffer_sync_partial( n_gdi_doublebuffer *p, s32 x, s32 y, s32 sx, s32 sy, bool is_pre )
{

	// [Mechanism]
	//
	//	Pre  : Window      => Back Buffer
	//	Post : Back Buffer => Window

	if ( p->upsidedown )
	{

		s32 ty = 0;
		while( 1 )
		{

			s32 target_fy = y + sy - 1 - ty;
			s32 target_ty = y + ty;

			if ( is_pre )
			{
				BitBlt( p->hdc_compat, x,target_fy,sx,1, p->hdc       , x,target_ty, SRCCOPY );
			} else {
				BitBlt( p->hdc       , x,target_fy,sx,1, p->hdc_compat, x,target_ty, SRCCOPY );
			}

			ty++;
			if ( ty >= sy ) { break; }
		}

	} else {

		if ( is_pre )
		{
			BitBlt( p->hdc_compat, x,y,sx,sy, p->hdc       , x,y, SRCCOPY );
		} else {
			BitBlt( p->hdc       , x,y,sx,sy, p->hdc_compat, x,y, SRCCOPY );
		}

	}


	return;
}

#define n_gdi_doublebuffer_exit( p ) n_gdi_doublebuffer_exit_partial( p, 0,0,(p)->sx,(p)->sy )

void
n_gdi_doublebuffer_exit_partial( n_gdi_doublebuffer *p, s32 x, s32 y, s32 sx, s32 sy )
{

	// Post Sync

	n_gdi_doublebuffer_sync_partial( p, x,y,sx,sy, false );

/*
	HMODULE hmod = LoadLibrary( n_posix_literal( "Msimg32.dll" ) );
	FARPROC func = GetProcAddress( hmod, "AlphaBlend" );
	if ( func )
	{
		BLENDFUNCTION bf = { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
		func( p->hdc, 0,0,sx,sy, p->hdc_compat, 0,0,sx,sy, bf );
	}
	FreeLibrary( hmod );
*/

	n_gdi_doublebuffer_cleanup( p );


	return;
}




u32
n_gdi_doublebuffer_colorref2argb( HWND hwnd, COLORREF color )
{

	n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );

	HDC hdc = n_gdi_doublebuffer_init( &db, hwnd, NULL, 1,1 );

	if ( db.bpp < 16 )
	{

		color = GetNearestColor( hdc, color );
		color = n_bmp_pal2rgb( color );

	} else
	if ( db.bpp < 24 )
	{

		// [x] : Win9x : 32bpp to 16bpp : the system uses many conversion methods
		//
		//	GetDIBits()'d color and GetPixel()'d color will be different

		// [x] : this code is not working with 32bpp DIBSection

//n_posix_debug_literal( "%08x", color );
		SetPixel( hdc, 0,0, color );
		//color = GetPixel( hdc, 0,0 );

		n_bmp_1st_fast( &db.bmp, 1,1 );

		BITMAPINFO bi = { N_BMP_INFOH( &db.bmp ), { { 0,0,0,0 } } };
		GetDIBits( hdc, db.hbmp, 0,N_BMP_SY( &db.bmp ), N_BMP_PTR( &db.bmp ), &bi, DIB_RGB_COLORS );

		n_bmp_ptr_get_fast( &db.bmp, 0,0, &color );

		n_bmp_free( &db.bmp );

//n_posix_debug_literal( "%08x", color );

	} else {

		color = n_bmp_pal2rgb( color );

	}

	n_gdi_doublebuffer_cleanup( &db );


	return n_bmp_alpha_visible_pixel( color );
}

void
n_gdi_doublebuffer_fill( n_gdi_doublebuffer *p, COLORREF color )
{

	if ( p->bpp == 32 )
	{

		n_bmp_flush( &p->bmp, n_gdi_doublebuffer_colorref2argb( p->hgui, color ) );

	} else {

		RECT r = { 0,0,p->sx,p->sy };
		n_win_box( NULL, p->hdc_compat, &r, color );

	}


	return;
}

void
n_gdi_doublebuffer_mix( n_gdi_doublebuffer *p, COLORREF color_t, double blend )
{

	if ( p->bpp == 32 )
	{

		n_bmp_flush_mixer( &p->bmp, n_gdi_doublebuffer_colorref2argb( p->hgui, color_t ), blend );

	} else {

		s32 x = 0;
		s32 y = 0;
		while( 1 )
		{

			COLORREF color_f = GetPixel( p->hdc, x,y );

			color_t = n_win_color_blend( color_f, color_t, blend );

			SetPixelV( p->hdc, x,y, color_t );

			x++;
			if ( x >= p->sx )
			{
				x = 0;

				y++;
				if ( y >= p->sy ) { break; }
			}
		}

	}


	return;
}

void
n_gdi_doublebuffer_visible( n_gdi_doublebuffer *p )
{

	if ( p->bpp == 32 )
	{
		n_bmp_alpha_visible( &p->bmp );
	} else {
		//
	}

	return;
}


#endif // _H_NONNON_WIN32_GDI_DOUBLEBUFFER

