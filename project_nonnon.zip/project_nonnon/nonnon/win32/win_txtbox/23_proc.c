// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static bool n_win_txtbox_printclient = false;

int
n_win_txtbox_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	// [Needed] : don't pass to DefWindowProc() when return value is non-zero


	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_CREATE :

		if ( false == p->is_static_ownerdraw )
		{
			// [Needed] : when button ownerdraw

			// [x] : you need to initialize manually

			//n_win_txtbox_proc_menu_editbox( hwnd, msg, wparam, lparam, p );
			//n_win_txtbox_proc_menu_linenum( hwnd, msg, wparam, lparam, p );
		}

	break;


	case WM_SETTINGCHANGE :

		// [!] : you need to call this manually

		//n_win_txtbox_metrics( p );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		if ( p->style & N_WIN_TXTBOX_STYLE__DI_HDC )
		{
			p->hdc = di->hDC;
		}

		n_win_txtbox_draw_partial( p, &di->rcItem, true, -1, -1 );


		// [x] : conflict with n_win_smallbutton.c
/*
		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_refresh( &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_refresh( &p->vscr );
		}
*/
	}
	break;


	case WM_PRINTCLIENT :
	{

		if ( n_win_txtbox_printclient == false ) { break; }


		p->hdc = (HDC) wparam;

		//RECT r; GetWindowRect( p->hwnd, &r );

		HFONT pf = SelectObject( p->hdc, n_win_font_get( p->hwnd ) );

		n_win_txtbox_draw_partial( p, NULL, true, -1, -1 );

		SelectObject( p->hdc, pf );

	}
	break;


	case WM_SETCURSOR :

		if (
			( n_win_txtbox_is_hovered( p ) )
			&&
			( hwnd == n_win_cursor2hwnd() )
		)
		{

			n_win_txtbox_on_setcursor( p );

			return true;
		}

	break;


	} // switch


	if ( p->is_static_ownerdraw ) { n_win_txtbox_proc_mouse( hwnd, msg, wparam, lparam, p ); }


	if ( p->mouse_input_stop_onoff == false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &p->vscr );
		}

	}


	return 0;
}


