// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_win_txtbox_hwndprintf(         p, f, ... ) n_win_hwndprintf( n_win_hwnd_toplevel( ( p )->hwnd ), f, ##__VA_ARGS__ )
#define n_win_txtbox_hwndprintf_literal( p, f, ... ) n_win_txtbox_hwndprintf( p, n_posix_literal( f ), ##__VA_ARGS__ )

// internal
void
n_win_txtbox_debug_count( n_win_txtbox *p )
{

	static int i = 0;

	n_win_txtbox_hwndprintf_literal( p, "%d", i );

	i++;

	return;
}

void
n_win_txtbox_refresh( n_win_txtbox *p )
{

	n_win_refresh( p->hwnd, false );


	return;
}

void
n_win_txtbox_message_redirect( n_win_txtbox *p, HWND hwnd, UINT msg )
{

	if ( p->is_static_ownerdraw )
	{
		n_win_message_send(               hwnd  , WM_COMMAND, msg, p->hwnd );
	} else {
		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );
	}

	return;
}


