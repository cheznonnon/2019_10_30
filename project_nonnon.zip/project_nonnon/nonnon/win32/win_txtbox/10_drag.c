// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_drag_select2drag( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }

	p->drag_cch_x = p->select_cch_x;
	p->drag_cch_y = p->select_cch_y;

	return;
}

bool
n_win_txtbox_drag_scroll( n_win_txtbox *p )
{

	bool done = false;


	if ( p == NULL ) { return done; }


	s32 stop_sx = p->select_cch_x;
	if ( ( p->shift_dragging == VK_RIGHT )&&( p->select_cch_sx > 0 ) ) { stop_sx += p->select_cch_sx; }

	s32 y = p->select_cch_y;
	if ( ( p->shift_dragging == VK_DOWN )&&( p->select_cch_sy > 1 ) ) { y += p->select_cch_sy - 1; }

	s32 tsx = ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx ) / p->font_pxl_sx;

	s32 tabbed_sx = 0; n_win_txtbox_tabbedmetrics( p, y, -1,p->hover_cch_x,-1, NULL,NULL,&tabbed_sx );
	if (
		( ( p->shift_dragging == VK_UP )||( p->shift_dragging == VK_DOWN ) )
		&&
		( tabbed_sx >= tsx )
	)
	{
		stop_sx = tabbed_sx;
	}

	s32 fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
	s32 tx = 0; n_win_txtbox_tabbedmetrics( p, y, -1,stop_sx,-1, NULL,NULL,&tx );
	s32 fy = p->scroll_cch_tabbed_y;
	s32 ty = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy;


	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		if ( p->hover_cch_y < fy )
		{
//n_win_txtbox_hwndprintf_literal( p, " Up : %d ", ty );

			done              = true;
			p->shift_dragging = VK_UP;

			n_win_txtbox_scroll( p, fx, p->hover_cch_y );

		} else
		if ( p->hover_cch_y > ty )
		{
//n_win_txtbox_hwndprintf_literal( p, " Down : %d ", ty );

			done              = true;
			p->shift_dragging = VK_DOWN;

			n_win_txtbox_scroll( p, fx, p->hover_cch_y - p->page_cch_tabbed_sy + 1 );

		}

	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{

		// [Needed] : for combination x and y

		fy = p->scroll_cch_tabbed_y;

		if ( tx >= tsx )
		{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", tx );

			if ( p->is_font_monospace )
			{

				done              = true;
				p->shift_dragging = VK_RIGHT;

				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx, fy );

			} else {

				if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->caret_pxl_x > p->canvas_real_pxl_sx ) )
				{
					done              = true;
					p->shift_dragging = VK_RIGHT;

					s32 osx = p->caret_pxl_x - p->canvas_real_pxl_sx;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + osx, p->scroll_cch_tabbed_y );
				} else
				if ( ( p->caret_pxl_x - ( p->number_pxl_sx + p->number_pad_pxl_sx ) ) > p->canvas_real_pxl_sx )
				{
					done              = true;
					p->shift_dragging = VK_RIGHT;

					s32 osx = ( p->caret_pxl_x - ( p->number_pxl_sx + p->number_pad_pxl_sx ) ) - p->canvas_real_pxl_sx;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + osx, p->scroll_cch_tabbed_y );
				}

			}

		} else
		if ( fx > tx )
		{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", tx );

			done              = true;
			p->shift_dragging = VK_LEFT;

			n_posix_char *line = n_txt_get( &p->txt, y );

			s32 tmp_x = 0; n_win_txtbox_tabbedmetrics( p, y, -1,-1,fx, NULL,&tmp_x,NULL );
			s32     l = 0; n_win_txtbox_caret_l( line, tmp_x, &l );
			s32 tmp   = 0; n_win_txtbox_tabbedmetrics( p, y, -1, l,-1, &tmp,  NULL,NULL );

			n_win_txtbox_scroll( p, tmp, fy );

		}

	}


	return done;
}

void
n_win_txtbox_drag( n_win_txtbox *p )
{
//return;

	if ( p == NULL ) { return; }


	s32  x = n_posix_minmax( 0, p->txt.sx, p->hover_cch_x );
	s32  y = n_posix_minmax( 0, p->txt.sy, n_posix_min_s32( p->hover_cch_y, p->drag_cch_y ) );
	s32 sx = 0;
	s32 sy = n_posix_minmax( 0, p->txt.sy - y, 1 + abs( n_posix_max_s32( 0, p->hover_cch_y ) - p->drag_cch_y ) );


	n_posix_char *line = n_txt_get( &p->txt, y );

	if ( p->drag_cch_x == x )
	{
//n_win_txtbox_hwndprintf_literal( p, " Stopped " );

		p->shift_dragging = 0;

	} else
	if ( p->drag_cch_x < x )
	{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT " );

		p->shift_dragging = VK_RIGHT;

		n_win_txtbox_caret_m( line, x, &x );

		sx = abs( x - p->drag_cch_x );
		 x = n_posix_min_s32( x, p->drag_cch_x );

	} else
	if ( p->drag_cch_x > x )
	{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT " );

		p->shift_dragging = VK_LEFT;

		n_win_txtbox_caret_m( line, x, &x );

		sx = abs( x - p->drag_cch_x );
		 x = n_posix_min_s32( x, p->drag_cch_x );

	}


	if ( sy <= 1 )
	{

		extern void n_win_txtbox_reset_line_minmax( n_win_txtbox* );
		n_win_txtbox_reset_line_minmax( p );

	} else {
//n_win_txtbox_hwndprintf_literal( p, " %d : %d : %d : %d ", sy, x, p->select_cch_x, p->line_min_cch_x );
//if ( y != p->select_cch_y ) { n_win_txtbox_hwndprintf_literal( p, " ! " ); }

		 x = 0;
		sx = N_WIN_TXTBOX_ALL;

		if ( p->drag_cch_y < p->hover_cch_y )
		{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN " );

			p->shift_dragging = VK_DOWN;

			if ( p->partial_selection_onoff )
			{

				if ( p->line_min_onoff == false )
				{
					p->line_min_onoff = true;
					p->line_min_cch_x = p->drag_cch_x;
				}

				p->line_max_cch_x = p->hover_cch_x;

//n_win_txtbox_hwndprintf_literal( p, " Min " );

				if ( y == p->select_cch_y )
				{
					 x = 0;
					sx = p->hover_cch_x;
				}

			}

		} else
		if ( p->drag_cch_y > p->hover_cch_y )
		{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP " );

			p->shift_dragging = VK_UP;

			if ( p->partial_selection_onoff )
			{

				p->line_min_cch_x = p->hover_cch_x;

				if ( p->line_max_onoff == false )
				{
					p->line_max_onoff = true;
					p->line_max_cch_x = p->drag_cch_x;
				}

//n_win_txtbox_hwndprintf_literal( p, " Max : %d %d ", y, ( p->select_cch_y + p->select_cch_sy - 1 ) );

				if ( y == p->select_cch_y )
				{
					 x = p->hover_cch_x;
					sx = N_WIN_TXTBOX_ALL;
				}

			}

		}

		if ( p->partial_selection_onoff )
		{
			if ( sx == 0 )
			{
				 x = 0;
				sx = N_WIN_TXTBOX_ALL;
			}
		}

	}
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );


	n_win_txtbox_select_set( p, x, y, sx, sy, false );
	n_win_txtbox_drag_scroll( p );
	//n_win_txtbox_drag_select2drag( p );


	return;
}


