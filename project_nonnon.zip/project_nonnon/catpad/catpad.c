// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"


#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/time.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win32/ole/IDropTarget.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_iconbutton.c"
#include "../nonnon/win32/win_menu.c"
#include "../nonnon/win32/win_smallbutton.c"
#include "../nonnon/win32/win_statusbar_ownerdraw.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/small_close.c"
#include "../nonnon/project/small_find.c"
#include "../nonnon/project/macro.c"


#include "_font.c"




// [!] : Shared

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_CATPAD ( 0 )

#endif // #ifndef NONNON_APPS


#define N_CATPAD_APPNAME                          "CatPad"
#define N_CATPAD_APPNAME_LITERAL n_posix_literal( "CatPad" )


#define N_CATPAD_MSG_BINARY      n_posix_literal( "BINARY" )
#define N_CATPAD_MSG_UNICODE_NIL n_posix_literal( "Non-Unicode" )
#define N_CATPAD_MSG_UNICODE_LIL n_posix_literal( "Unicode Little Endian" )
#define N_CATPAD_MSG_UNICODE_BIG n_posix_literal( "Unicode Big Endian" )
#define N_CATPAD_MSG_UNICODE_UTF n_posix_literal( "Unicode UTF-8" )
#define N_CATPAD_MSG_CR          n_posix_literal( "CR" )
#define N_CATPAD_MSG_LF          n_posix_literal( "LF" )
#define N_CATPAD_MSG_CRLF        n_posix_literal( "CRLF" )
#define N_CATPAD_MSG_READONLY    n_posix_literal( "Read Only" )
#define N_CATPAD_MSG_FIND        n_project_string_go


#define N_CATPAD_CALC            n_posix_literal( "calc.exe" )




// [!] : Components

#define N_CATPAD_INI_CCH  ( 1024 )
#define N_CATPAD_SYNC_CCH ( 1024 ) 


extern void n_catpad_status_refresh( void );
extern void n_catpad_overwrite_onoff( bool );
extern void n_catpad_font_init( void );
extern void n_catpad_search( HWND );
extern void n_catpad_focus ( HWND );
extern void n_catpad_ini_write( void );
extern void n_catpad_sync_send( HWND, const n_posix_char* );


static n_win_txtbox  n_catpad_txtbox_editor;
static bool          n_catpad_txtbox_onoff;
static bool          n_catpad_txtbox_onoff_default;
static n_win_txtbox  n_catpad_txtbox_search;
static n_win         n_catpad_nwin;
static n_win         n_catpad_nwin_ini;
static int           n_catpad_initial_state;
static s32           n_catpad_input_resizer_sx = 0;
static s32           n_catpad_input_resizer_icon_sx;
static HFONT         n_catpad_hfont;
static HWND          n_catpad_hfind;
static HWND          n_catpad_heditor;
static HWND          n_catpad_hpopup;

static n_posix_char  n_catpad_find[ N_CATPAD_SYNC_CCH ];
static n_posix_char  n_catpad_tab [ N_CATPAD_INI_CCH  ];
static n_posix_char  n_catpad_eol [ N_CATPAD_INI_CCH  ];




#include "./catpad_flashwindow.c"

#include "./catpad_main.c"

#include "./catpad_config.c"
#include "./catpad_filter.c"
#include "./catpad_fontchooser.c"
#include "./catpad_ini.c"
#include "./catpad_input_resizer.c"
#include "./catpad_keyfocus.c"
#include "./catpad_search.c"
#include "./catpad_sync.c"




// CatPad

#define H_TOOLBAND       n_catpad_hgui[ 0 ]
#define H_BTN_TOPMOST    n_catpad_hgui[ 1 ]
#define H_BTN_OVERWRITE  n_catpad_hgui[ 2 ]
#define H_BTN_CONFIG     n_catpad_hgui[ 3 ]
#define H_BTN_FONT       n_catpad_hgui[ 4 ]
#define H_BTN_CALC       n_catpad_hgui[ 5 ]
#define H_BTN_NDUMP      n_catpad_hgui[ 6 ]
#define H_BTN_FIND       n_catpad_hgui[ 7 ]
#define H_BTN_RESET      n_catpad_hgui[ 8 ]
#define GUI_MAX                         9

#define H_EDITOR         n_catpad_heditor
#define H_TXTBOX         n_catpad_txtbox_editor.hwnd
#define H_SEARCH         n_catpad_txtbox_search.hwnd


#define N_CATPAD_ICON_OFFSET_NDUMP   ( 7 )
#define N_CATPAD_ICON_OFFSET_TOPMOST ( 2 )


static HWND              n_catpad_hgui[ GUI_MAX ];
static n_posix_char     *n_catpad_fname_last       =  NULL;
static bool              n_catpad_ndump_onoff      = false;
static bool              n_catpad_input_gray_onoff = false;


static n_win_smallbutton n_catpad_findicon;
static n_win_smallbutton n_catpad_reseticon;


static n_win_statusbar_ownerdraw n_catpad_statusbar;


static bool              n_catpad_search_monospace = false;
static bool              n_catpad_txtbox_monospace =  true;


static bool              n_catpad_dwm_transbg_onoff = false;


static n_win_titlemenu   n_catpad_titlemenu;
static n_win_simplemenu  n_catpad_simplemenu;






// internal
void
n_catpad_day_of_week( n_posix_char *str, size_t cch )
{

	// [Needed] : an explicit name like "ja-JP" will not work

	setlocale( LC_ALL, "" );


	time_t     rawtime; time( &rawtime );
	struct tm *timeinfo = localtime( &rawtime );

	n_posix_strftime_literal( str, cch, "%A", timeinfo );

//n_posix_debug_literal( "%s", str );

	return;

}

// internal
void
n_catpad_overwrite_onoff( bool onoff )
{

	EnableWindow( H_BTN_OVERWRITE, ( onoff != false ) );
	EnableWindow( H_BTN_NDUMP,     ( onoff == false ) );

	return;
}

// internal
void
n_catpad_editor_refresh( void )
{

	// [!] : true only available

	n_win_refresh( H_EDITOR, true );
	n_win_refresh( H_TXTBOX, true );

	return;
}

// internal
void
n_catpad_font_init( void )
{

	// [Needed] : set every time

	n_win_edit_margin_set( H_EDITOR, 4,0 );


	if ( n_catpad_txtbox_monospace )
	{
		n_win_font_exit( n_win_font_get( H_EDITOR ) );
		n_win_font_exit( n_win_font_get( H_TXTBOX ) );

		n_win_font_set( H_EDITOR, n_catpad_hfont, true );
		n_win_font_set( H_TXTBOX, n_catpad_hfont, true );
	}

	if ( n_catpad_search_monospace )
	{
		n_win_font_set( H_SEARCH, n_catpad_hfont, true );
	}


	n_win_txtbox_metrics_maxwidth_all( &n_catpad_txtbox_editor );


	n_catpad_editor_refresh();


	return;
}

// internal
void
n_catpad_title( HWND hwnd, n_posix_char *name )
{

	n_posix_char *s = n_string_carboncopy( name );
	n_string_replace( s, s, N_STRING_BSLASH, N_STRING_SLASH );


	// [!] : default

	n_posix_char *title = n_string_path_cat( s, n_posix_literal( " - " ), N_CATPAD_APPNAME_LITERAL, NULL );


	// [!] : set readonly if the same titled window is running

	HWND h = NULL;
	while( 1 )
	{
		h = FindWindowEx( NULL, h, NULL, title );
		if ( h == NULL ) { break; }
		if ( h != hwnd ) { break; }
	}

	if ( h != NULL )
	{
		n_catpad_txtbox_editor.txt.readonly = N_TXT_READONLY_ON;
		n_string_path_free( title );
		title = n_string_path_cat( s, n_posix_literal( " (Read Only)- " ), N_CATPAD_APPNAME_LITERAL, NULL );
	}


	n_win_text_set( hwnd, title );
	n_string_path_free( title );


	n_string_free( s );


	return;
}

// internal
void
n_catpad_editor_ntxt_set( void )
{

	// [MSDN] : multiline edit control's limit
	//
	//	WinNT : 0x7FFFFFFE :  2 GB (auto-expansion)
	//	Win9x : 0x0000FFFF : 64 KB (default 32 KB)

	// [!] : Win9x : reality
	//
	//	Text   : cannot display 40KB to 50KB or higher
	//	Binary : cannot display 25KB to 35KB or higher


	const size_t limitsize = 1024 * 32;


	// [Needed] : n_catpad_txtbox_onoff_default is read-only

	n_catpad_txtbox_onoff = n_catpad_txtbox_onoff_default;


	if ( n_sysinfo_version_9x() )
	{
		if ( n_catpad_txtbox_editor.txt.byte >= limitsize ) { n_catpad_txtbox_onoff = true; }
		if ( n_catpad_txtbox_editor.txt.readonly          ) { n_catpad_txtbox_onoff = true; }
	}


	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_BINARY )
	{
		n_catpad_ntxt_binary2text( &n_catpad_txtbox_editor.txt );
	} else {
		n_win_txtbox_vector_stream( &n_catpad_txtbox_editor, N_STRING_CRLF, true );
	}

	if ( n_catpad_txtbox_onoff )
	{

		// [Patched] : edit control compatible behavior

		//n_win_txtbox_line_add( &n_catpad_txtbox_editor, n_catpad_txtbox_editor.txt.sy, N_STRING_EMPTY );


		n_win_txtbox_reset_scroll( &n_catpad_txtbox_editor      );
		n_win_txtbox_scroll      ( &n_catpad_txtbox_editor, 0,0 );

	} else {

		// [!] : Win9x : previous one remains

		n_win_text_set_literal( H_EDITOR, "" );
		n_win_message_send( H_EDITOR, EM_SETLIMITTEXT, 0, limitsize );

		n_win_text_set( H_EDITOR, n_catpad_txtbox_editor.txt.stream );


		if ( n_catpad_txtbox_editor.txt.readonly == false )
		{
			n_win_message_send( H_EDITOR, EM_SETREADONLY, false, 0 );
		} else {
			n_win_message_send( H_EDITOR, EM_SETREADONLY,  true, 0 );
		}

	}


	return;
}

// internal
void
n_catpad_linenumber_refresh( bool redraw )
{

	static s32 line_cur = -1;
	static s32 line_prv = -1;
	static s32 line_max = -1;


	if ( redraw ) { line_prv = -1; }


	if ( n_catpad_txtbox_onoff )
	{
		line_cur = n_win_txtbox_line_cur( &n_catpad_txtbox_editor ) + 1;
		line_max = n_win_txtbox_line_max( &n_catpad_txtbox_editor );
	} else {
		line_cur = n_win_edit_line_cur( H_EDITOR ) + 1;
		line_max = n_win_edit_line_max( H_EDITOR );
	}

	if ( line_prv != line_cur )
	{
		line_prv = line_cur;

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, " Line : %ld/%ld", line_cur, line_max );

		n_win_statusbar_od_text( &n_catpad_statusbar, str, 0 );
	}


	return;
}

// internal
void
n_catpad_status_refresh( void )
{

	n_catpad_linenumber_refresh( true );


	n_posix_char str[ 100 ];

	size_t size = 0;
	if ( n_posix_stat_is_exist( n_catpad_fname_last ) ) { size = n_posix_stat_size( n_catpad_fname_last ); }
	n_posix_sprintf_literal( str, " %lu Byte ", (u32) size );

	n_win_statusbar_od_text( &n_catpad_statusbar, str, 1 );


	n_posix_char *str_ch = N_STRING_EMPTY;
	n_posix_char *str_nl = N_STRING_EMPTY;

	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_NIL    ) { str_ch = N_CATPAD_MSG_UNICODE_NIL; } else
	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_LIL    ) { str_ch = N_CATPAD_MSG_UNICODE_LIL; } else
	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_BIG    ) { str_ch = N_CATPAD_MSG_UNICODE_BIG; } else
	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_UTF    ) { str_ch = N_CATPAD_MSG_UNICODE_UTF; }

	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_BINARY ) { str_nl = N_CATPAD_MSG_BINARY;      } else
	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_CR     ) { str_nl = N_CATPAD_MSG_CR;          } else
	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_LF     ) { str_nl = N_CATPAD_MSG_LF;          } else
	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_CRLF   ) { str_nl = N_CATPAD_MSG_CRLF;        }

	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_BINARY )
	{
		n_posix_sprintf_literal( str, " %s ", str_nl );
	} else {
		n_posix_sprintf_literal( str, " %s : %s ", str_ch, str_nl );
	}

	n_win_statusbar_od_text( &n_catpad_statusbar, str, 2 );


	return;
}

// internal
void
n_catpad_resize( HWND hwnd )
{

	const bool redraw = true;


	s32 ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );


	static bool is_first = true;

	if ( is_first )
	{

		is_first = false;


		// [!] : n_catpad_ini_read() needs to be already done

		int nwset = N_WIN_SET_INNERPOS;

		if ( ( n_catpad_nwin.posx == -1 )||( n_catpad_nwin.posy == -1 ) )
		{
			nwset |= N_WIN_SET_CENTERING;
		} else {
			nwset |= N_WIN_SET_NEEDPOS;
		}

		if ( ( n_catpad_nwin.rcsx == -1 )||( n_catpad_nwin.rcsy == -1 ) )
		{
			n_catpad_nwin.rcsy = GetSystemMetrics( SM_CYMAXIMIZED ) / 2;
			n_catpad_nwin.rcsx = n_catpad_nwin.rcsy * 2;
		}

//n_posix_debug_literal( "%d", n_catpad_nwin.state );
		n_win_set( hwnd, &n_catpad_nwin, n_catpad_nwin.rcsx,n_catpad_nwin.rcsy, nwset );

	} else {

		n_win_set( hwnd, &n_catpad_nwin, -1,-1, n_project_n_win_set() );

	}


	s32 csx = n_catpad_nwin.csx;
	s32 csy = n_catpad_nwin.csy;

	n_win_move_simple( H_TOOLBAND,            0,0, csx,ico, redraw );

	n_win_move_simple( H_BTN_TOPMOST,   0 * ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_OVERWRITE, 1 * ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_CONFIG,    2 * ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_FONT,      3 * ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_CALC,      4 * ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_NDUMP,     5 * ico,0, ico,ico, redraw );
	n_catpad_input_resizer_icon_sx =    6 * ico;


	{

		if ( n_catpad_input_resizer_sx == 0 )
		{
			n_catpad_input_resizer_sx = ( ctl * 12 );
		}


		s32 sx = n_posix_min_s32( n_catpad_input_resizer_sx, csx - n_catpad_input_resizer_icon_sx - ( m * 2 ) );
		s32 sy = ( ctl *  1 );
		s32 x  = ( csx - m ) - sx;
		s32 y  = ( ico - ctl ) / 2;

		n_win_move( H_SEARCH, x,y, sx,sy, redraw );

		n_win_txtbox_smallbutton_embed( &n_catpad_txtbox_search, &n_catpad_findicon,  0, redraw );
		n_win_txtbox_smallbutton_embed( &n_catpad_txtbox_search, &n_catpad_reseticon, 1, redraw );

	}


	{

		s32 toolsy, statsy, editsy;


		toolsy = ico;
		statsy = ctl;
		editsy = csy - ( toolsy + statsy );

		n_win_move_simple( H_EDITOR, 0,toolsy, csx,editsy, redraw );
		n_win_move_simple( H_TXTBOX, 0,toolsy, csx,editsy, redraw );


		// [Needed] : Win9x : scroll metrics is not reset
		// [x] : scroll position will reset when theme is changed

		//n_win_txtbox_scroll_refresh( &n_catpad_txtbox_editor );

	}

	n_win_statusbar_od_automove( &n_catpad_statusbar );


	return;
}

// internal
void
n_catpad_focus( HWND hwnd )
{

	HWND h = GetFocus();


	if ( n_catpad_txtbox_onoff )
	{
		if ( h != H_TXTBOX ) { SetFocus( H_TXTBOX ); }
	} else {
		if ( h != H_EDITOR ) { SetFocus( H_EDITOR ); }
	}


	return;
}

// internal
void
n_catpad_ui_refresh( HWND hwnd )
{

	// [Needed] : EnableWindow() before uncheck

	n_catpad_overwrite_onoff( false );

	EnableWindow( H_BTN_CONFIG, ( n_catpad_txtbox_editor.txt.readonly == N_TXT_READONLY_OFF ) );


	if ( n_catpad_txtbox_onoff == false )
	{
		ShowWindow( H_TXTBOX, SW_HIDE   );
		ShowWindow( H_EDITOR, SW_NORMAL );
	} else {
		ShowWindow( H_EDITOR, SW_HIDE   );
		ShowWindow( H_TXTBOX, SW_NORMAL );
	}


	n_catpad_nwin.scrollx = n_catpad_nwin.scrolly = 0;
	n_catpad_resize( hwnd );


	n_win_txtbox_refresh( &n_catpad_txtbox_editor );

	// [Needed] : Win9x : scroll metrics is not reset
	n_win_txtbox_scroll_refresh( &n_catpad_txtbox_editor );


	n_catpad_focus( hwnd );
	n_catpad_status_refresh();
	n_catpad_linenumber_refresh( true );


	return;
}

bool
n_catpad_txt_load( n_win_txtbox *p, const n_posix_char *cmdline )
{

	bool ret = true;


	if ( n_catpad_txtbox_onoff )
	{
		ret = n_win_txtbox_txt_load(  p     , cmdline );
	} else {
		ret = n_txt_load           ( &p->txt, cmdline );
	}


	return ret;
}

// internal
void
n_catpad_newfile( HWND hwnd, n_posix_char *fname )
{

	if ( n_catpad_txtbox_onoff ) { n_win_txtbox_reset( &n_catpad_txtbox_editor ); }

	if ( n_catpad_txt_load( &n_catpad_txtbox_editor, fname ) ) 
	{

		n_posix_char *dir = n_string_path_folder_current_new();
		n_posix_char *pth = n_string_path_make_new( dir, n_posix_literal( "new.txt" ) );

		if ( n_catpad_txt_load( &n_catpad_txtbox_editor, pth ) )
		{
			n_txt_new( &n_catpad_txtbox_editor.txt );
		}

		n_catpad_title( hwnd, pth );

		n_string_path_free( n_catpad_fname_last );
		n_catpad_fname_last = n_string_path_carboncopy( pth );

		n_string_path_free( dir );
		n_string_path_free( pth );

	} else {

		n_string_path_free( n_catpad_fname_last );
		n_catpad_fname_last = n_string_path_carboncopy( fname );

		n_catpad_title( hwnd, fname );

	}


	n_catpad_editor_ntxt_set();
	n_catpad_ui_refresh( hwnd );


	// [!] : Tricky : to turn off

	int index = N_APPS_ICON_OFFSET_CATPAD + N_CATPAD_ICON_OFFSET_NDUMP;

	n_catpad_ndump_onoff = true;
	n_catpad_ndump_onoff = n_win_iconbutton_checklike( H_BTN_NDUMP, index, index, n_catpad_ndump_onoff );


	return;
}

// internal
void
n_catpad_save( HWND hwnd )
{

	if ( n_catpad_txtbox_onoff )
	{

		// [Patched] : edit control compatible behavior

		//n_win_txtbox_line_del( &n_catpad_txtbox_editor, n_catpad_txtbox_editor.txt.sy );

	} else {

		// [!] : add NUL('\0') at allocation

		int cch      = n_win_text_len( H_EDITOR ) + 1;
		int byte     = cch * sizeof( n_posix_char );
		int newline  = n_catpad_txtbox_editor.txt.newline;
		int unicode  = n_catpad_txtbox_editor.txt.unicode;
		int readonly = n_catpad_txtbox_editor.txt.readonly;


		n_posix_char *ptr = n_memory_new( byte );

		n_win_text_get( H_EDITOR, ptr, cch );

#ifdef UNICODE

		n_unicode_bom_restore_utf16_le( ptr, byte );

#else // #ifdef UNICODE

		// [!] : EditControlA adds an extra newline

		n_catpad_string_remove_newline( ptr, ptr );
//n_posix_debug( ptr );

#endif // #ifdef UNICODE

		if ( n_catpad_txtbox_onoff )
		{
			n_win_txtbox_txt_load_onmemory( &n_catpad_txtbox_editor    , ptr, byte );
		} else {
			n_txt_load_onmemory           ( &n_catpad_txtbox_editor.txt, ptr, byte );
		}

		n_catpad_txtbox_editor.txt.byte     = byte;
		n_catpad_txtbox_editor.txt.newline  = newline;
		n_catpad_txtbox_editor.txt.unicode  = unicode;
		n_catpad_txtbox_editor.txt.readonly = readonly;

	}


	// [!] : make a file writable 
	//
	//	"readonly", "system", "hidden"

	bool ret = false;

	u32 attrib;


	attrib = GetFileAttributes( n_catpad_fname_last );
	SetFileAttributes( n_catpad_fname_last, 0 );

	ret = n_win_txtbox_txt_save( &n_catpad_txtbox_editor, n_catpad_fname_last );

	if ( attrib != INVALID_FILE_ATTRIBUTES )
	{
		SetFileAttributes( n_catpad_fname_last, attrib );
	}

	n_explorer_refresh( false );


	if ( ret )
	{
		n_project_dialog_info( hwnd, n_project_string_error );
	} else {
		n_catpad_overwrite_onoff( false );
	}

	n_catpad_status_refresh();


	return;
}

// internal
void
n_catpad_dump( HWND hwnd )
{

	if ( IsWindowEnabled( H_BTN_OVERWRITE ) ) { return; }


	if ( n_catpad_ndump_onoff == false )
	{
		n_catpad_newfile( hwnd, n_catpad_fname_last );
		return;
	}


	n_catpad_ntxt_dump( &n_catpad_txtbox_editor.txt, n_catpad_fname_last );

	n_catpad_txtbox_editor.txt.readonly = true;


	n_catpad_editor_ntxt_set();
	n_catpad_ui_refresh( hwnd );


	return;
}

#ifndef _WIN64
static WNDPROC n_catpad_toolband_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_catpad_toolband_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_catpad_toolband_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_COMMAND :
	{

		HWND h       = (HWND) lparam;
		HWND hparent = n_win_hwnd_toplevel( hwnd );

		if ( h == H_BTN_TOPMOST )
		{

			static bool topmost = false;

			int index = N_APPS_ICON_OFFSET_CATPAD + N_CATPAD_ICON_OFFSET_TOPMOST;
			topmost = n_win_iconbutton_checklike( h, index, index, topmost );

			n_win_topmost( hparent, topmost );

			n_catpad_focus( hparent );

		} else

		if ( h == H_BTN_OVERWRITE )
		{

			n_catpad_save( hparent );

			n_catpad_focus( hparent );

		} else

		if ( h == H_BTN_CONFIG )
		{

			n_win_gui( hparent, WINDOW, n_catpad_config_wndproc, &n_catpad_hpopup );

		} else

		if ( h == H_BTN_FONT )
		{

			n_win_gui( hparent, WINDOW, n_catpad_fontchooser_wndproc, &n_catpad_hpopup );

		} else

		if ( h == H_BTN_CALC )
		{

			n_win_exec( N_CATPAD_CALC, SW_NORMAL );

		} else

		if ( h == H_BTN_NDUMP )
		{

			int index = N_APPS_ICON_OFFSET_CATPAD + N_CATPAD_ICON_OFFSET_NDUMP;
			n_catpad_ndump_onoff = n_win_iconbutton_checklike( h, index, index, n_catpad_ndump_onoff );


			n_catpad_dump( hparent );

			n_catpad_focus( hparent );

		}// else

	}
	break;


	} // switch


	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_TOPMOST   );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_OVERWRITE );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_CONFIG    );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_FONT      );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_CALC      );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_NDUMP     );


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_catpad_toolband_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

#ifndef _WIN64
static WNDPROC n_catpad_editor_subclass_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_catpad_editor_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_catpad_editor_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_MBUTTONDOWN :

		if ( n_win_is_input( VK_CONTROL ) )
		{
			n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), n_font_size_default( hwnd ) );
			n_catpad_font_init();
			return 0;
		}

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_catpad_editor_subclass_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

#ifndef _WIN64
static WNDPROC n_catpad_txtbox_subclass_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_catpad_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_catpad_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_MBUTTONDOWN :

		if ( n_catpad_txtbox_editor.is_static_ownerdraw != false ) { break; }

		if ( n_win_is_input( VK_CONTROL ) )
		{
			n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), n_font_size_default( hwnd ) );
			n_catpad_font_init();
			return 0;
		}

	break;


	case WM_IME_NOTIFY :

		if ( wparam == IMN_SETOPENSTATUS )
		{
			n_win_txtbox_ime_watch( &n_catpad_txtbox_search );
		}

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_catpad_txtbox_subclass_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

#ifndef _WIN64
static WNDPROC n_catpad_search_subclass_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_catpad_search_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_catpad_search_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_IME_NOTIFY :

		if ( wparam == IMN_SETOPENSTATUS )
		{
			n_win_txtbox_ime_watch( &n_catpad_txtbox_editor );
		}

	break;


	} // switch

#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_catpad_search_subclass_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

u32
n_catpad_bmp_pal2rgb( u32 color )
{

	// 24bit / RGB()   : 0BGR
	// 32bit / Palette : ARGB : BGRA on file

	int a = 255;//n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );


	return n_bmp_argb( a,b,g,r );
}

void
n_catpad_smallbutton_color_set( void )
{

	n_catpad_findicon .color_bg      = n_catpad_bmp_pal2rgb( n_catpad_txtbox_editor.color_back__enabled );//n_bmp_rgb(   1,  1,  1 );
	n_catpad_findicon .color_grayed  = n_catpad_bmp_pal2rgb( n_catpad_txtbox_editor.color_back_disabled );//n_bmp_rgb( 111,111,111 );
	n_catpad_reseticon.color_bg      = n_catpad_bmp_pal2rgb( n_catpad_txtbox_editor.color_back__enabled );//n_bmp_rgb(   1,  1,  1 );
	n_catpad_reseticon.color_grayed  = n_catpad_bmp_pal2rgb( n_catpad_txtbox_editor.color_back_disabled );//n_bmp_rgb( 111,111,111 );
	n_catpad_reseticon.color_hovered = n_bmp_rgb( 255,  0,  0 );

}

int
n_catpad_txtbox_input_style( void )
{

	int style = N_WIN_TXTBOX_STYLE_ONELINE | N_WIN_TXTBOX_STYLE_EDITBOX;

	if ( n_catpad_dwm_transbg_onoff )
	{
		style |= N_WIN_TXTBOX_STYLE_TRANSBG;
	} else {
		if ( n_sysinfo_version_vista_or_later() )
		{
			style |= N_WIN_TXTBOX_STYLE_VISIBLE;
		}
	}


	return style;
}

void
n_catpad_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_refresh( H_TOOLBAND, true );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_TOPMOST   );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_OVERWRITE );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_CONFIG    );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_FONT      );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_CALC      );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_NDUMP     );


		n_catpad_dwm_transbg_onoff = n_project_dwm_is_on();


		n_win_stdfont_init( n_catpad_hgui, GUI_MAX );

		if ( n_catpad_txtbox_monospace == false )
		{
			n_win_stdfont_init( &H_EDITOR, 1 );
			n_win_stdfont_init( &H_TXTBOX, 1 );
		}

		n_win_txtbox_metrics( &n_catpad_txtbox_editor );


		if ( n_catpad_search_monospace == false )
		{
			n_win_stdfont_init( &H_SEARCH, 1 );
		}

		n_catpad_txtbox_search.style = n_catpad_txtbox_input_style();

		n_win_txtbox_metrics( &n_catpad_txtbox_search );

		n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );


		n_win_smallbutton_on_settingchange_by_data( &n_catpad_findicon , H_BTN_FIND , n_project_small_find  );
		n_win_smallbutton_on_settingchange_by_data( &n_catpad_reseticon, H_BTN_RESET, n_project_small_close );

		n_catpad_findicon .dwm_transbg_onoff = n_catpad_dwm_transbg_onoff;
		n_catpad_reseticon.dwm_transbg_onoff = n_catpad_dwm_transbg_onoff;

		n_catpad_smallbutton_color_set();


		n_catpad_resize( hwnd );

	break;


	} // switch


}

LRESULT CALLBACK
n_catpad_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT window_init_timer_id = 0;


	n_catpad_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == window_init_timer_id )
		{

			if ( n_catpad_initial_state == SIZE_MAXIMIZED )
			{
				ShowWindow( hwnd, SW_MAXIMIZE );
			} else {
				ShowWindow( hwnd, SW_NORMAL   );
			}

			n_win_timer_exit( hwnd, window_init_timer_id );

		}

	break;


	case WM_CREATE :
	{

		// Global

		n_game_timegettime_init();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_exedir2curdir();

		n_catpad_sync_init();
		n_catpad_ini_read( hwnd );

		n_win_smallbutton_zero( &n_catpad_findicon  );
		n_win_smallbutton_zero( &n_catpad_reseticon );

		n_win_txtbox_zero( &n_catpad_txtbox_editor );
		n_win_txtbox_zero( &n_catpad_txtbox_search );

		n_catpad_dwm_transbg_onoff = n_project_dwm_is_on();

		n_project_darkmode();
		//n_win_darkmode_onoff = true;


		// Window

		n_win_init_literal( hwnd, "", "CATPAD_0_MAIN", "" );


		n_win_gui_literal( hwnd, CANVAS,  "", &H_BTN_FIND  );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_BTN_RESET );

		{
			int style        = n_catpad_txtbox_input_style();
			int style_option = N_WIN_TXTBOX_OPTION_ONELINE_FADEOUT;

			n_win_txtbox_init( &n_catpad_txtbox_search, hwnd, style, style_option );
		}

		n_win_gui_literal( hwnd, CANVAS,  "", &H_TOOLBAND  );
		n_win_gui_literal( hwnd, EDITOR,  "", &H_EDITOR    );

		n_win_statusbar_od_init( &n_catpad_statusbar, hwnd, 3 );

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_EDITBOX;
			style = style | N_WIN_TXTBOX_STYLE_HSCROLL | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM;
			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM;

			n_win_txtbox_init( &n_catpad_txtbox_editor, hwnd, style, style_option );

			n_catpad_txtbox_editor.tab_mark = n_catpad_tab;
			n_catpad_txtbox_editor.eol_mark = n_catpad_eol;
		}

		n_win_gui_literal( H_TOOLBAND, FICOBTN, "", &H_BTN_TOPMOST   );
		n_win_gui_literal( H_TOOLBAND, FICOBTN, "", &H_BTN_OVERWRITE );
		n_win_gui_literal( H_TOOLBAND, FICOBTN, "", &H_BTN_CONFIG    );
		n_win_gui_literal( H_TOOLBAND, FICOBTN, "", &H_BTN_FONT      );
		n_win_gui_literal( H_TOOLBAND, FICOBTN, "", &H_BTN_CALC      );
		n_win_gui_literal( H_TOOLBAND, FICOBTN, "", &H_BTN_NDUMP     );

		n_win_icon_add( H_BTN_TOPMOST,   NULL, N_APPS_ICON_OFFSET_CATPAD + 2 );
		n_win_icon_add( H_BTN_OVERWRITE, NULL, N_APPS_ICON_OFFSET_CATPAD + 3 );
		n_win_icon_add( H_BTN_CONFIG,    NULL, N_APPS_ICON_OFFSET_CATPAD + 4 );
		n_win_icon_add( H_BTN_FONT,      NULL, N_APPS_ICON_OFFSET_CATPAD + 5 );
		n_win_icon_add( H_BTN_CALC,      NULL, N_APPS_ICON_OFFSET_CATPAD + 6 );
		n_win_icon_add( H_BTN_NDUMP,     NULL, N_APPS_ICON_OFFSET_CATPAD + 7 );


		// Style

		n_project_window_resizable( hwnd );


		n_win_simplemenu_zero( &n_catpad_simplemenu );
		n_win_simplemenu_init( &n_catpad_simplemenu );

		//n_win_simplemenu_set( &n_catpad_simplemenu, 0, NULL, n_posix_literal( "[ ]Close" ), NULL );


		n_win_titlemenu_zero( &n_catpad_titlemenu );
		n_win_titlemenu_init_main( &n_catpad_titlemenu, hwnd, &n_catpad_simplemenu );


		n_catpad_keyfocus_main( H_SEARCH, H_EDITOR, H_TXTBOX );


		n_win_iconbutton_init( hwnd, H_BTN_TOPMOST   );
		n_win_iconbutton_init( hwnd, H_BTN_OVERWRITE );
		n_win_iconbutton_init( hwnd, H_BTN_CONFIG    );
		n_win_iconbutton_init( hwnd, H_BTN_FONT      );
		n_win_iconbutton_init( hwnd, H_BTN_CALC      );
		n_win_iconbutton_init( hwnd, H_BTN_NDUMP     );


		n_win_smallbutton_init_by_data( &n_catpad_findicon , H_BTN_FIND , n_project_small_find  );
		n_win_smallbutton_init_by_data( &n_catpad_reseticon, H_BTN_RESET, n_project_small_close );

		n_catpad_reseticon.fade_sink_onoff   = false;

		n_catpad_findicon .dwm_transbg_onoff = n_catpad_dwm_transbg_onoff;
		n_catpad_reseticon.dwm_transbg_onoff = n_catpad_dwm_transbg_onoff;

		n_catpad_smallbutton_color_set();


#ifdef _WIN64
		SetWindowSubclass( H_TOOLBAND, n_catpad_toolband_subclass, 0, 0 );
		SetWindowSubclass( H_SEARCH  , n_catpad_search_subclass  , 0, 0 );
		SetWindowSubclass( H_EDITOR  , n_catpad_editor_subclass  , 0, 0 );
		SetWindowSubclass( H_TXTBOX  , n_catpad_txtbox_subclass  , 0, 0 );
#else  // #ifdef _WIN64
		n_catpad_toolband_pfunc        = n_win_gui_subclass_set( H_TOOLBAND, n_catpad_toolband_subclass );
		n_catpad_search_subclass_pfunc = n_win_gui_subclass_set( H_SEARCH  , n_catpad_search_subclass   );
		n_catpad_editor_subclass_pfunc = n_win_gui_subclass_set( H_EDITOR  , n_catpad_editor_subclass   );
		n_catpad_txtbox_subclass_pfunc = n_win_gui_subclass_set( H_TXTBOX  , n_catpad_txtbox_subclass   );
#endif // #ifdef _WIN64


		// Init

		n_win_stdfont_init( n_catpad_hgui, GUI_MAX );

		if ( n_catpad_txtbox_monospace == false )
		{
			n_win_stdfont_init( &H_EDITOR, 1 );
			n_win_stdfont_init( &H_TXTBOX, 1 );
		}

		if ( n_catpad_search_monospace == false )
		{
			n_win_stdfont_init( &H_SEARCH, 1 );
		}

		n_catpad_font_init();

		n_catpad_hfind = H_SEARCH;

		if ( false == n_catpad_sync_is_first_check( hwnd ) )
		{
//n_posix_debug_literal( " %s ", n_catpad_sync_str );

			n_posix_char str[ N_CATPAD_SYNC_CCH ];

			n_catpad_sync_recv( hwnd, str );

			if ( false == n_string_is_empty( str ) )
			{
				n_string_copy( str, n_catpad_find );
			}

		}
		n_win_txtbox_line_set( &n_catpad_txtbox_search, 0, n_catpad_find );
		n_win_txtbox_select_tail_set( &n_catpad_txtbox_search );

		n_win_message_send( hwnd, WM_COMMAND, WM_KILLFOCUS, H_SEARCH );
		n_win_message_send( hwnd, WM_COMMAND, WM_KEYDOWN  , H_SEARCH );


		// Display

		{

			n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_CATPAD, cmdline );

#endif // #ifdef NONNON_APPS

			n_catpad_newfile( hwnd, cmdline );

			n_string_path_free( cmdline );

		}


		ShowWindow( hwnd, SW_HIDE );

		if ( window_init_timer_id == 0 ) { window_init_timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, window_init_timer_id, 1 );

	}
	break;


	case WM_CTLCOLORSTATIC :

		if ( (HWND) lparam == H_EDITOR )
		{
			return (LRESULT) GetStockObject( WHITE_BRUSH );
		}

	break;


	case WM_DROPFILES :
	{

		// [!] : for popup windows

		if ( false == IsWindowEnabled( hwnd ) ) { break; }

		n_posix_char *fname = n_win_dropfiles_multiple_new( hwnd, wparam );

		n_catpad_newfile( hwnd, fname );

		n_string_path_free( fname );

	}
	break;


	case WM_SETFOCUS :

		n_catpad_focus( hwnd );

	break;


	case WM_ACTIVATE :

		// [Needed] : WinXP or earlier : tearing prevention
		//
		//	don't use Vista or later : this causes flickering

		if ( n_catpad_txtbox_onoff == false ) { break; }

		if ( n_sysinfo_version_vista_or_later() ) { break; }

		if ( wparam == WA_INACTIVE )
		{
			n_catpad_txtbox_editor.style |=  N_WIN_TXTBOX_STYLE__DI_HDC;
		} else {
			n_catpad_txtbox_editor.style &= ~N_WIN_TXTBOX_STYLE__DI_HDC;
		}

	break;


	case WM_ERASEBKGND :

		// [Needed] : prevent redraw error

		return true;

	break;


	case WM_MOVE :

		if ( false == IsZoomed( hwnd ) )
		{
			RECT r; GetWindowRect( hwnd, &r );
			n_catpad_nwin_ini.posx = r.left;
			n_catpad_nwin_ini.posy = r.top;
		}

	break;

	case WM_SIZE :

		n_catpad_resize( hwnd );


		n_catpad_nwin_ini.state = wparam;

		if ( wparam == SIZE_RESTORED )
		{
			n_win_size_client( hwnd, &n_catpad_nwin_ini.rcsx, &n_catpad_nwin_ini.rcsy );
#ifdef _MSC_VER
			// [!] : reason is unknown

			int dpi = n_win_dpi( hwnd );

			if ( dpi >= 192 )
			{
				// [!] : 200%
			} else
			if ( dpi >= 168 )
			{
				// [!] : 175%

				n_catpad_nwin_ini.rcsx += 6;
				n_catpad_nwin_ini.rcsy += 6;
			} else
			if ( dpi >= 144 )
			{
				// [!] : 150%

				n_catpad_nwin_ini.rcsx += 6;
				n_catpad_nwin_ini.rcsy += 6;
			} else
			if ( dpi >= 120 )
			{
				// [!] : 125%

				n_catpad_nwin_ini.rcsx += 2;
				n_catpad_nwin_ini.rcsy += 2;
			} else {
				// [!] : 100%
			}
#endif // #ifdef _MSC_VER
		}

	break;


	case WM_MBUTTONDOWN :

		if ( n_catpad_txtbox_onoff == false ) { break; }

		if ( n_win_is_input( VK_CONTROL ) )
		{
			n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), n_font_size_default( hwnd ) );
			n_catpad_font_init();
		}

	break;

	case WM_MOUSEWHEEL :

		if ( n_win_is_input( VK_CONTROL ) )
		{

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, true ) * -1;
			int size  = n_font_size( n_catpad_hfont );
//n_win_hwndprintf_literal( hwnd, " %d : %d ", delta, size );

			n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), size + delta );
			n_catpad_font_init();

			return 0;
		}

		if ( n_catpad_txtbox_onoff ) { break; }

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;

		if ( h == H_EDITOR )
		{
			if ( EN_CHANGE == HIWORD( wparam ) )
			{
				n_catpad_overwrite_onoff( true );
			}
		} else
		if ( h == n_catpad_txtbox_editor.hwnd )
		{
			if ( wparam == WM_KEYDOWN )
			{
				n_catpad_overwrite_onoff( true );
			}
		} else
		if ( h == H_SEARCH )
		{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), "" );

			if ( wparam == WM_SETFOCUS )
			{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), " SETFOCUS " );

				n_catpad_input_gray_onoff = false;
				n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );

				n_win_smallbutton_onoff( &n_catpad_findicon,   true, true );
				n_win_smallbutton_onoff( &n_catpad_reseticon,  true, true );

			} else
			if ( wparam == WM_KILLFOCUS )
			{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), " KILLFOCUS " );

				n_win_txtbox_unselect( &n_catpad_txtbox_search );
				n_win_txtbox_select_tail_set( &n_catpad_txtbox_search );

				n_catpad_input_gray_onoff = true;
				n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );

				n_win_smallbutton_onoff( &n_catpad_findicon,  false, true );
				n_win_smallbutton_onoff( &n_catpad_reseticon, false, true );

			} else
			if ( wparam == WM_KEYDOWN )
			{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), " WM_KEYDOWN " );

				n_posix_char *str = n_win_txtbox_line_get_new( &n_catpad_txtbox_search, 0 );

				if ( n_string_is_empty( str ) )
				{
					n_win_smallbutton_show( &n_catpad_reseticon, SW_HIDE );
					n_win_txtbox_oneline_fade_out( &n_catpad_txtbox_search );
				} else {
					n_win_smallbutton_show( &n_catpad_reseticon, SW_NORMAL );
				}

				n_string_free( str );

			}

		} else
		if ( h == H_BTN_FIND )
		{

			if ( n_win_smallbutton_is_clicked_up( wparam ) )
			{
				n_catpad_search( hwnd );
			}

		} else
		if ( h == H_BTN_RESET )
		{

			if ( n_win_smallbutton_is_clicked( wparam ) )
			{
				n_string_truncate( n_catpad_find );
				n_catpad_sync_send( hwnd, N_STRING_EMPTY );
			}

		}// else

	}
	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{

			// [!] : WinXP or later : ANSI DBCS : byte count will return

			//n_posix_debug_literal( "%d", GetWindowTextLength( H_EDITOR ) );


			//n_clipboard_text_set( hwnd, N_STRING_EMPTY );

		} else
		if ( wparam == VK_F2 )
		{
//n_posix_debug_literal( "!" );
			//n_win_scrollbar_reset( &n_catpad_txtbox_editor.vscr );
			//n_win_txtbox_reset_scroll( &n_catpad_txtbox_editor );

			//n_win_scrollbar_metrics( &n_catpad_txtbox_editor.vscr );

			//n_bmp_free( &n_catpad_txtbox_editor.vscr.bmp_th );

			//n_win_scrollbar_scroll_unit( &n_catpad_txtbox_editor.vscr, 0, N_WIN_SCROLLBAR_SCROLL_AUTO );
			//n_win_scrollbar_draw_always( &n_catpad_txtbox_editor.vscr, true );

			//n_win_txtbox_refresh( &n_catpad_txtbox_editor );

		} else
		if ( wparam == VK_F5 )
		{

			if ( n_catpad_txtbox_editor.txt.readonly ) { break; }

			n_posix_char str[ 100 ];

			if ( n_win_is_input( VK_CONTROL ) )
			{
				n_catpad_day_of_week( str, 100 );
			} else {
				n_time_string_stime( str );
			}

			if ( n_catpad_txtbox_onoff )
			{
				n_win_txtbox_selection_cat( &n_catpad_txtbox_editor,  str );
			} else {
				n_win_edit_line_insert    ( H_EDITOR, str );
			}

			n_catpad_overwrite_onoff( true );

			n_catpad_editor_refresh();

		} else
		if ( wparam == VK_F9 )
		{
/*
			s32           cch = n_clipboard_text_get( hwnd, NULL );
			n_posix_char *str = n_string_new( cch ); n_clipboard_text_get( hwnd, str );

			n_posix_debug_literal( "%d %x", cch, str[ 0 ] );

			n_string_free( str );
*/
		}// else

	break;


	case WM_CLOSE :

		//n_catpad_resize( hwnd );

		n_catpad_ini_write();

#ifdef _WIN64
		RemoveWindowSubclass( H_TOOLBAND, n_catpad_toolband_subclass, 0 );
		RemoveWindowSubclass( H_SEARCH  , n_catpad_search_subclass  , 0 );
		RemoveWindowSubclass( H_EDITOR  , n_catpad_editor_subclass  , 0 );
		RemoveWindowSubclass( H_TXTBOX  , n_catpad_txtbox_subclass  , 0 );
#else  // #ifdef _WIN64
		n_win_gui_subclass_set( H_TOOLBAND, n_catpad_toolband_pfunc        );
		n_win_gui_subclass_set( H_SEARCH  , n_catpad_search_subclass_pfunc );
		n_win_gui_subclass_set( H_EDITOR  , n_catpad_editor_subclass_pfunc );
		n_win_gui_subclass_set( H_TXTBOX  , n_catpad_txtbox_subclass_pfunc );
#endif // #ifdef _WIN64


		n_win_smallbutton_exit( &n_catpad_findicon  );
		n_win_smallbutton_exit( &n_catpad_reseticon );


		n_win_txtbox_exit( &n_catpad_txtbox_editor );
		n_win_txtbox_exit( &n_catpad_txtbox_search );


		n_catpad_sync_exit();


		n_win_iconbutton_exit( hwnd, H_BTN_TOPMOST   );
		n_win_iconbutton_exit( hwnd, H_BTN_OVERWRITE );
		n_win_iconbutton_exit( hwnd, H_BTN_CONFIG    );
		n_win_iconbutton_exit( hwnd, H_BTN_FONT      );
		n_win_iconbutton_exit( hwnd, H_BTN_CALC      );
		n_win_iconbutton_exit( hwnd, H_BTN_NDUMP     );


		n_win_font_exit( n_catpad_hfont );

		n_win_stdfont_exit( n_catpad_hgui, GUI_MAX );

		n_win_statusbar_od_exit( &n_catpad_statusbar );

		if ( n_catpad_txtbox_monospace == false )
		{
			n_win_stdfont_exit( &H_EDITOR, 1 );
			n_win_stdfont_exit( &H_TXTBOX, 1 );
		}

		if ( n_catpad_search_monospace == false )
		{
			n_win_stdfont_exit( &H_SEARCH, 1 );
		}


		n_win_titlemenu_exit( &n_catpad_titlemenu );

		n_win_simplemenu_exit( &n_catpad_simplemenu );


		n_string_path_free( n_catpad_fname_last );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_game_timegettime_exit();


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_catpad_linenumber_refresh( false );


	if ( n_catpad_sync_proc( hwnd, msg, wparam, lparam ) )
	{

		n_catpad_sync_recv( hwnd, n_catpad_find );


		n_posix_char *str = n_win_txtbox_line_get_new( &n_catpad_txtbox_search, 0 );
//n_posix_debug_literal( " Get %s\n Find %s ", str, n_catpad_find );

		if ( false == n_string_is_same( str, n_catpad_find ) )
		{
			n_win_txtbox_line_set( &n_catpad_txtbox_search, 0, n_catpad_find );
			n_win_txtbox_select_tail_set( &n_catpad_txtbox_search );

			n_win_txtbox_refresh( &n_catpad_txtbox_search );

			n_win_message_send( hwnd, WM_COMMAND, WM_KEYDOWN, n_catpad_txtbox_search.hwnd );
		}

		n_string_free( str );

	}


	if ( msg == n_catpad_sync_msg_is_exist )
	{
		return true;
	}


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_catpad_txtbox_editor );
		if ( ret ) { return ret; }
	}


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_catpad_txtbox_search );
		if ( ret ) { return ret; }
	}

	n_win_statusbar_od_proc( hwnd,msg,wparam,lparam, &n_catpad_statusbar );

	n_win_smallbutton_proc( hwnd, msg, wparam, lparam, &n_catpad_findicon  );
	n_win_smallbutton_proc( hwnd, msg, wparam, lparam, &n_catpad_reseticon );

	if ( n_catpad_txtbox_search.is_captured == false )
	{

		bool ret = n_catpad_input_resizer_proc( hwnd, msg, wparam, lparam, H_SEARCH, H_TOOLBAND );

		s32 cursor_x, cursor_y;
		n_win_cursor_position_relative( hwnd, &cursor_x, &cursor_y );
		if (
			( ret == false )
			&&
			(
				( false == n_catpad_input_resizer_onoff( hwnd, H_SEARCH, cursor_x, cursor_y ) )
				||
				( msg == WM_DRAWITEM )
			)
		)
		{
			n_project_toolband_proc( hwnd, msg, wparam, lparam, H_TOOLBAND, true );
		}

	} else {

		n_project_toolband_proc( hwnd, msg, wparam, lparam, H_TOOLBAND, true );

	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_catpad_main( NULL, n_catpad_wndproc );
}

#endif // #ifndef NONNON_APPS


#undef H_TOOLBAND
#undef H_BTN_TOPMOST
#undef H_BTN_OVERWRITE
#undef H_BTN_CONFIG
#undef H_BTN_FONT
#undef H_BTN_CALC
#undef H_BTN_NDUMP
#undef H_BTN_FIND
#undef H_BTN_RESET
#undef GUI_MAX

#undef H_EDITOR
#undef H_TXTBOX
#undef H_SEARCH

