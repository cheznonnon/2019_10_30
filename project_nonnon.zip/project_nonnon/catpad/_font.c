// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




HFONT
n_font_default( void )
{

	LOGFONT lf = n_win_font_hfont2logfont( GetStockObject( SYSTEM_FIXED_FONT ) );

	return n_win_font_logfont2hfont( &lf );
}

int
n_font_size_default( HWND hwnd )
{

	int              cb = sizeof( NONCLIENTMETRICS );
	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;
	SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );


	return ncm.lfCaptionFont.lfHeight;
	//return (int) ceil( (double) ncm.lfCaptionFont.lfHeight * ( (double) n_win_dpi( hwnd ) / 96 ) );
}

int
n_font_size( HFONT hfont )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );

//n_posix_debug_literal( "%d", lf.lfHeight );

	return lf.lfHeight;
}

n_posix_char*
n_font_name( HFONT hfont )
{

	static n_posix_char str[ LF_FACESIZE ];


	LOGFONT lf = n_win_font_hfont2logfont( hfont );
	n_posix_sprintf_literal( str, "%s", lf.lfFaceName );


	return str;
}

HFONT
n_font_bold_onoff( HFONT hfont, bool onoff )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );


	if ( onoff )
	{
		lf.lfWeight = FW_NORMAL;
	} else {
		lf.lfWeight = FW_BOLD;
	}


	n_win_font_exit( hfont );

	return n_win_font_logfont2hfont( &lf );
}

void
n_font_hfont2hexdump( HFONT hfont, n_posix_char *str )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );
	u8      *p = (void*) &lf;


	int i, ii;


	i = ii = 0;
	while( 1 )
	{

		str[ ii + 0 ] = n_string_binary2hexchar( p[ i ] / 16 );
		str[ ii + 1 ] = n_string_binary2hexchar( p[ i ] % 16 );

		ii += 2;

		i++;
		if ( i >= sizeof( LOGFONT ) ) { break; }
	}

	n_string_terminate( str, ii );


	return;
}

HFONT
n_font_hexdump2hfont( n_posix_char *str )
{

	int byte = sizeof( LOGFONT ) - ( n_posix_strlen( str ) / sizeof( n_posix_char ) );
	if ( byte != 0 ) { return n_font_default(); }


	LOGFONT lf;
	ZeroMemory( &lf, sizeof( LOGFONT ) );

	u8 *p = (void*) &lf;


	int i, ii;


	i = ii = 0;
	while( 1 )
	{

		p[ i ]  = n_string_hexchar2binary( str[ ii + 0 ] ) * 16;
		p[ i ] += n_string_hexchar2binary( str[ ii + 1 ] );

		ii += 2;

		i++;
		if ( i >= sizeof( LOGFONT ) ) { break; }
	}


	return n_win_font_logfont2hfont( &lf );
}

