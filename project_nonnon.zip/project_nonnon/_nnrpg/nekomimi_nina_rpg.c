// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/input.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
#include "../nonnon/game/transition.c"


#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win32/gdi.c"

#include "../nonnon/project/macro.c"




// Shared

#define FRAME_MAX         2


#define SOUND_MAIN_BGM    &sound[ 0 ]
#define SOUND_TRANSITION  &sound[ 1 ]
#define SOUND_SIDH_FADING &sound[ 2 ]
#define SOUND_FANFARE     &sound[ 3 ]
#define SOUND_GAMEOVER    &sound[ 4 ]
#define SOUND_MAX                 5

#define PHASE_NONE        0
#define PHASE_INIT        1
#define PHASE_BATTLE      2
#define PHASE_FANFARE     3
#define PHASE_GAMEOVER    4

#define PERSONNEL_NONE   -1
#define PERSONNEL_NINA    0
#define PERSONNEL_NONO    1
#define PERSONNEL_SIDH    2
#define PERSONNEL_MAX     3

#define REDRAW_NONE      ( 0 << 0 )
#define REDRAW_COMMAND   ( 1 << 0 )
#define REDRAW_MAINWIN   ( 1 << 1 )
#define REDRAW_CHARA     ( 1 << 2 )
#define REDRAW_ANIMATION ( 1 << 3 )
#define REMAKE_COMMAND   ( 1 << 4 )
#define REMAKE_MAINWIN   ( 1 << 5 )
#define REMAKE_ANIMATION ( 1 << 6 )


static int phase  = PHASE_INIT;
static int redraw = REDRAW_MAINWIN | REDRAW_CHARA;
static int focus  = PERSONNEL_NONE;
static int target = PERSONNEL_NONE;

static n_bmp bmp_bg;


// Component

#include "./_personnel.c"

static n_personnel  personnel[ PERSONNEL_MAX ];
static n_window     window_main;

static n_game_sound sound[ SOUND_MAX ];

static n_bmp        transition_bmp_old;
static n_bmp        transition_bmp_new;
static bool         transition_onoff   = false;
static bool         screenshaker_onoff = false;

static n_game_input input;




// internal
void
n_nnrpg_mainwindow( n_window *w, n_personnel *p, int p_count, int focus )
{

	int i   = 0;
	int cch = 0;
	while( 1 )
	{

		n_posix_char *f = N_PERSONNEL_FOCUS_OFF;

		if ( focus == i ) { f = N_PERSONNEL_FOCUS_ON; }

		cch += n_posix_sprintf_literal
		(
			&w->msg[ cch ],
			"%s%s   HP%3d%% MP%3d%% %s",
			f,
			p[ i ].name,
			p[ i ].hp,
			p[ i ].mp,
			N_STRING_CRLF
		);


		i++;
		if ( i >= p_count ) { break; }
	}


	n_window_bitmap( w );


	return;
}

// internal
void
n_nnrpg_redraw( void )
{

	if ( redraw == REDRAW_NONE ) { return; }


	// Benchmarker

	u32 tick_before = n_posix_tickcount();


	// Erase

	if ( redraw & REDRAW_MAINWIN )
	{

		n_window_erase( &window_main );

	}

	if ( redraw & REDRAW_COMMAND )
	{

		if ( focus != PERSONNEL_SIDH ) { n_personnel_command_erase( &personnel[ focus ] ); }

	}

	if ( redraw & ( REDRAW_CHARA | REDRAW_ANIMATION ) )
	{

		n_personnel_erase( &personnel[ PERSONNEL_NINA ] );
		n_personnel_erase( &personnel[ PERSONNEL_NONO ] );
		n_personnel_erase( &personnel[ PERSONNEL_SIDH ] );

	}


	// Remake

	if ( redraw & REMAKE_MAINWIN )
	{

		n_nnrpg_mainwindow( &window_main, personnel, PERSONNEL_MAX, focus );

	}

	if ( redraw & REMAKE_COMMAND )
	{

		if ( focus != PERSONNEL_SIDH ) { n_personnel_command_bitmap( &personnel[ focus ] ); }

	}

	if ( redraw & REMAKE_ANIMATION )
	{

		int cmd = n_personnel_command_get( &personnel[ focus ] );

		if ( cmd == N_COMMAND_ATTACK )
		{
			screenshaker_onoff = n_personnel_attack( &personnel[ focus ], &personnel[ target ] );
		} else
		if ( cmd == N_COMMAND_MAGIC )
		{
			screenshaker_onoff = n_personnel_magic( &personnel[ focus ], &personnel[ target ] );
		} else
		if ( cmd == N_COMMAND_HEAL )
		{
			n_personnel_heal( &personnel[ focus ] );
		}// else

	}


	// Draw

	if ( redraw & REDRAW_MAINWIN )
	{

		n_window_draw( &window_main );

	}

	if ( redraw & REDRAW_COMMAND )
	{

		if ( focus != PERSONNEL_SIDH ) { n_personnel_command_draw( &personnel[ focus ] ); }

	}

	if ( redraw & ( REDRAW_CHARA | REDRAW_ANIMATION ) )
	{

		n_personnel_draw( &personnel[ PERSONNEL_NINA ], ( focus == PERSONNEL_NINA ) );
		n_personnel_draw( &personnel[ PERSONNEL_NONO ], ( focus == PERSONNEL_NONO ) );
		n_personnel_draw( &personnel[ PERSONNEL_SIDH ], ( focus == PERSONNEL_SIDH ) );

	}


	// Reset

	if ( redraw & REDRAW_ANIMATION )
	{

		// [!] : ( msec_per_frame * frame_max ) == FPS

		const u32 msec_per_frame = 33;
		const int frame_max      = 6;
		const int frame_anim[]   = { 0,1,1,1,1,1 };


		static u32 timer = 0;
		static int frame = 0;

		if ( timer == 0 )
		{
			n_game_timer( &timer, 0 );
			n_personnel_command_erase( &personnel[ focus ] );
		}

		if ( n_game_timer( &timer, msec_per_frame ) )
		{

			n_game_timer( &timer, 0 );

			if ( focus != PERSONNEL_SIDH )
			{
				personnel[ focus ].chr.srcy = personnel[ focus ].chr.sy * frame_anim[ frame ];
			}

			frame++;
			if ( frame >= frame_max )
			{

				timer = frame = 0;

				n_personnel_neutral( &personnel[ PERSONNEL_NINA ] );
				n_personnel_neutral( &personnel[ PERSONNEL_NONO ] );
				n_personnel_neutral( &personnel[ PERSONNEL_SIDH ] );

				redraw = REMAKE_MAINWIN | REDRAW_MAINWIN | REDRAW_CHARA;

				focus = target = PERSONNEL_NONE;

			}

			{

				int step = 1 * metric.zoom;

				personnel[ PERSONNEL_NINA ].tip.y -= step;
				personnel[ PERSONNEL_NONO ].tip.y -= step;
				personnel[ PERSONNEL_SIDH ].tip.y -= step;

			}

		} else {

			redraw = REDRAW_CHARA | REDRAW_ANIMATION;

		}


		// [Needed] : every frames

		n_window_draw( &personnel[ PERSONNEL_NINA ].tip );
		n_window_draw( &personnel[ PERSONNEL_NONO ].tip );
		n_window_draw( &personnel[ PERSONNEL_SIDH ].tip );

		if ( screenshaker_onoff ) { n_game_screenshaker( 4 ); }

	} else {

		screenshaker_onoff = false;
		n_game_screenshaker( 0 );


		const u32 interval_input = 200;

		u32 tick_after = n_posix_tickcount() - tick_before;
		if ( interval_input > tick_after ) { n_posix_sleep( interval_input - tick_after ); }


		n_personnel_tip_exit( &personnel[ PERSONNEL_NINA ] );
		n_personnel_tip_exit( &personnel[ PERSONNEL_NONO ] );
		n_personnel_tip_exit( &personnel[ PERSONNEL_SIDH ] );


		redraw = REDRAW_NONE;

	}


	n_game_refresh_on();
	return;
}

// internal
void
n_nnrpg_input( void )
{

	if ( redraw != REDRAW_NONE ) { return; }


	const u32 interval_wait = 2000;


	if ( focus == PERSONNEL_NONE )
	{

		n_personnel_bulk_wait( personnel, PERSONNEL_MAX );
//n_game_hwndprintf_literal( "%d %d %d", personnel[ 0 ].wait, personnel[ 1 ].wait, personnel[ 2 ].wait );

		static u32 wait_timer = 0;

		if ( wait_timer == 0 )
		{

			n_game_timer( &wait_timer, 0 );

		} else
		if ( n_game_timer( &wait_timer, interval_wait ) )
		{

			static int p_focus = PERSONNEL_NONE;

			int i = 0;
			while( 1 )
			{

				focus = n_personnel_bulk_wait_focus( personnel, PERSONNEL_MAX );
				n_personnel_bulk_wait_reset( personnel, PERSONNEL_MAX );

				if ( focus != p_focus ) { break; }

				i++;
				if ( i >= 10 ) { break; }
			}

			p_focus = focus;

if ( n_game_input_loop( &input, '1' ) ) { focus = PERSONNEL_NINA; }
if ( n_game_input_loop( &input, '2' ) ) { focus = PERSONNEL_NONO; }
if ( n_game_input_loop( &input, '3' ) ) { focus = PERSONNEL_SIDH; }

			if ( focus != PERSONNEL_NONE )
			{
				redraw |= REMAKE_MAINWIN | REDRAW_MAINWIN;
				redraw |= REMAKE_COMMAND | REDRAW_COMMAND;
			}

		}

	} else
	if ( focus != PERSONNEL_SIDH )
	{

		if ( n_game_input_loop( &input, VK_UP ) )
		{

			n_personnel_command_up( &personnel[ focus ] );

			redraw = REMAKE_COMMAND | REDRAW_COMMAND;

		} else
		if ( n_game_input_loop( &input, VK_DOWN ) )
		{

			n_personnel_command_down( &personnel[ focus ] );

			redraw = REMAKE_COMMAND | REDRAW_COMMAND;

		} else
		if ( n_game_input_loop( &input, VK_SPACE ) )
		{

			target = PERSONNEL_SIDH;

			redraw |= REMAKE_MAINWIN | REDRAW_MAINWIN;
			redraw |= REDRAW_CHARA;
			redraw |= REMAKE_ANIMATION | REDRAW_ANIMATION;

		}// else

	} else
	if ( focus == PERSONNEL_SIDH )
	{

		// [!] : AI

		n_personnel_command_set( &personnel[ focus ], N_COMMAND_ATTACK );

		if ( personnel[ focus ].mp != 0 )
		{
			if ( personnel[ focus ].hp < 30 )
			{
				n_personnel_command_set( &personnel[ focus ], N_COMMAND_HEAL );
			} else
			if ( 0 == n_game_random( 10 ) )
			{
				n_personnel_command_set( &personnel[ focus ], N_COMMAND_MAGIC );
			}
		}

		if ( personnel[ PERSONNEL_NINA ].hp > personnel[ PERSONNEL_NONO ].hp )
		{
			target = PERSONNEL_NINA;
		} else
		if ( personnel[ PERSONNEL_NONO ].hp > personnel[ PERSONNEL_NINA ].hp )
		{
			target = PERSONNEL_NONO;
		} else {
			target = n_game_random( 2 );
		}

		redraw |= REMAKE_MAINWIN | REDRAW_MAINWIN;
		redraw |= REDRAW_CHARA;
		redraw |= REMAKE_ANIMATION | REDRAW_ANIMATION;

	}


	return;
}

// internal
void
n_nnrpg_reset( void )
{

	if ( redraw != REDRAW_NONE ) { return; }


	n_personnel_neutral( &personnel[ PERSONNEL_NINA ] );
	n_personnel_neutral( &personnel[ PERSONNEL_NONO ] );
	n_personnel_neutral( &personnel[ PERSONNEL_SIDH ] );

	personnel[ PERSONNEL_NINA ].hp = personnel[ PERSONNEL_NINA ].mp = 100;
	personnel[ PERSONNEL_NONO ].hp = personnel[ PERSONNEL_NONO ].mp = 100;
	personnel[ PERSONNEL_SIDH ].hp = personnel[ PERSONNEL_SIDH ].mp = 100;


	phase  = PHASE_INIT;

	redraw  = REDRAW_CHARA;
	redraw |= REMAKE_MAINWIN | REDRAW_MAINWIN;
	//redraw |= REMAKE_COMMAND | REDRAW_COMMAND;

	focus  = PERSONNEL_NONE;
	target = PERSONNEL_NONE;


	return;
}




void
n_game_init( void )
{

	// System

	n_bmp_safemode = false;


	n_metric_make();

	n_game_title_literal( "+++Nekomimi Nina RPG+++" );

	game.sx    = metric.csx;
	game.sy    = metric.csy;
	game.fps   = 30;
	game.color = n_bmp_black;


	// Zeroclear

	n_bmp_zero( &transition_bmp_old );
	n_bmp_zero( &transition_bmp_new );

	n_personnel_zero( &personnel[ PERSONNEL_NINA ] );
	n_personnel_zero( &personnel[ PERSONNEL_NONO ] );
	n_personnel_zero( &personnel[ PERSONNEL_SIDH ] );


	// Init

	n_game_sound_bulk_zero( sound, SOUND_MAX );

	n_game_sound_init_literal( SOUND_TRANSITION,  game.hwnd, "RC_WAV_INIT" );
	n_game_sound_init_literal( SOUND_SIDH_FADING, game.hwnd, "RC_WAV_FADE" );
	n_game_sound_init_literal( SOUND_FANFARE,     game.hwnd, "RC_WAV_FNFR" );
	n_game_sound_init_literal( SOUND_GAMEOVER,    game.hwnd, "RC_WAV_OVER" );

	{

		n_bmp_zero( &bmp_bg );
		n_bmp_1st_fast( &bmp_bg, game.sx, game.sy );

		u32 fg = n_bmp_rgb(  10, 10, 10 );
		u32 bg = n_bmp_rgb( 222,255,255 );// n_bmp_rgb( 255,255,255 );

		n_bmp_flush_gradient( &bmp_bg, fg,bg, N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_TOPLEFT );

	}

	n_personnel_init_literal( &personnel[ PERSONNEL_NINA ], "Nina   ",  20, 20, 50, "RC_BMP_NINA", "RC_WAV_0_00", "RC_WAV_1", "RC_WAV_2" );
	n_personnel_init_literal( &personnel[ PERSONNEL_NONO ], "Nono   ",  15, 25, 50, "RC_BMP_NONO", "RC_WAV_0_01", "RC_WAV_1", "RC_WAV_2" );
	n_personnel_init_literal( &personnel[ PERSONNEL_SIDH ], "CatSidh",  20, 33, 47, "RC_BMP_SIDH", "RC_WAV_0_02", "RC_WAV_1", "RC_WAV_2" );


	n_window_init( &window_main, metric.mainwin_x, metric.mainwin_y, metric.mainwin_sx, metric.mainwin_sy );
	n_nnrpg_mainwindow( &window_main, personnel, PERSONNEL_MAX, -1 );

	n_game_chara_pos( &personnel[ PERSONNEL_NINA ].chr, metric.chara_0_x, metric.chara_0_y );
	n_game_chara_pos( &personnel[ PERSONNEL_NONO ].chr, metric.chara_1_x, metric.chara_1_y );
	n_game_chara_pos( &personnel[ PERSONNEL_SIDH ].chr, metric.chara_2_x, metric.chara_2_y );


	n_game_input_zero( &input );
	n_game_input_init( &input, 0 );
	n_game_input_vk2udlr_default( &input );
	n_game_input_vk2button( &input, VK_SPACE, 0 );
	n_game_input_vk2button( &input, VK_SPACE, 1 );
	n_game_input_vk2button( &input, VK_SPACE, 2 );
	n_game_input_vk2button( &input, VK_SPACE, 3 );


	return;
}

void
n_game_loop( void )
{

	if ( false == n_game_refresh_is_off() ) { return; }


	if ( phase == PHASE_NONE )
	{

		if ( n_win_is_input( VK_SPACE ) ) { n_nnrpg_reset(); }

	} else
	if ( phase == PHASE_INIT )
	{

		if ( transition_onoff == false )
		{

			transition_onoff = true;


			n_game_sound_loop( SOUND_TRANSITION );


			n_bmp_new( &transition_bmp_old, game.sx, game.sy );
			n_bmp_carboncopy( &bmp_bg, &transition_bmp_new );

//n_bmp_save_literal( &transition_bmp_new, "ret.bmp" );


			metric.canvas = &transition_bmp_new;
			n_nnrpg_redraw();

			// [!] : "else" is needed

		} else
		if ( n_game_transition( &game.bmp, &transition_bmp_old, &transition_bmp_new, 2000, N_GAME_TRANSITION_WIPE_Y ) )
		{

			transition_onoff = false;


			n_game_sound_init_literal( SOUND_MAIN_BGM, game.hwnd, "./rc/nnrpg.mid" );


			metric.canvas = &game.bmp;


			phase = PHASE_BATTLE;

			n_personnel_command_set( &personnel[ PERSONNEL_NINA ], 0 );
			n_personnel_command_set( &personnel[ PERSONNEL_NONO ], 0 );
			n_personnel_command_set( &personnel[ PERSONNEL_SIDH ], 0 );

		}


		n_game_refresh_on();

	} else
	if ( phase == PHASE_BATTLE )
	{

		n_nnrpg_input();
		n_nnrpg_redraw();

		if ( n_game_sound_timer( SOUND_MAIN_BGM ) ) { n_game_sound_loop( SOUND_MAIN_BGM ); }

		if ( redraw == REDRAW_NONE )
		{

			if (
				( personnel[ PERSONNEL_NINA ].hp <= 0 )
				&&
				( personnel[ PERSONNEL_NONO ].hp <= 0 )
			)
			{

				phase = PHASE_GAMEOVER;

			} else
			if ( personnel[ PERSONNEL_SIDH ].hp <= 0 )
			{

				phase = PHASE_FANFARE;

			}

		}

	} else
	if ( phase == PHASE_FANFARE )
	{

		if ( transition_onoff == false )
		{

			transition_onoff = true;


			n_game_sound_loop( SOUND_SIDH_FADING );


			n_personnel *p = &personnel[ PERSONNEL_SIDH ];
			s32         x  = p->chr.x;
			s32         y  = p->chr.y;
			s32         sx = p->chr.sx;
			s32         sy = p->chr.sy; sy += (double) sy * 0.33;

			n_bmp_new_fast( &transition_bmp_old, sx,sy );
			n_bmp_new_fast( &transition_bmp_new, sx,sy );

			n_bmp_fastcopy( &game.bmp, &transition_bmp_old, x,y,sx,sy, 0,0 );
			n_bmp_fastcopy( &bmp_bg,   &transition_bmp_new, x,y,sx,sy, 0,0 );

			n_game_transition_offset_x = x;
			n_game_transition_offset_y = y;

		} else
		if ( n_game_transition( &game.bmp, &transition_bmp_old, &transition_bmp_new, 1000, N_GAME_TRANSITION_FADE ) )
		{

			transition_onoff = false;


			n_game_sound_exit( SOUND_MAIN_BGM );
			n_game_sound_loop( SOUND_FANFARE );


			n_game_transition_offset_x = 0;
			n_game_transition_offset_y = 0;

			phase = PHASE_NONE;

		}

		n_game_refresh_on();

	} else
	if ( phase == PHASE_GAMEOVER )
	{

		if ( transition_onoff == false )
		{

			transition_onoff = true;

			n_game_sound_exit( SOUND_MAIN_BGM );

			n_bmp_carboncopy( &game.bmp, &transition_bmp_old );
			n_bmp_carboncopy( &game.bmp, &transition_bmp_new );

			n_bmp_flush_grayscale( &transition_bmp_new );

		} else
		if ( n_game_transition( &game.bmp, &transition_bmp_old, &transition_bmp_new, 1000, N_GAME_TRANSITION_FADE ) )
		{

			transition_onoff = false;

			n_game_sound_loop( SOUND_GAMEOVER );

			phase = PHASE_NONE;

		}

		n_game_refresh_on();

	}


	return;
}

void
n_game_exit( void )
{

	int i = 0;
	while( 1 )
	{

		n_game_sound_exit( &sound[ i ] );

		i++;
		if ( i >= SOUND_MAX ) { break; }
	}


	n_bmp_free( &bmp_bg );

	n_bmp_free( &transition_bmp_old );
	n_bmp_free( &transition_bmp_new );

	n_window_exit( &window_main );

	n_personnel_exit( &personnel[ PERSONNEL_NINA ] );
	n_personnel_exit( &personnel[ PERSONNEL_NONO ] );
	n_personnel_exit( &personnel[ PERSONNEL_SIDH ] );


	n_game_input_exit( &input );


	return;
}

