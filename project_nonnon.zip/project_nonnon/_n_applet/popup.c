// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_popup.c"
#include "../nonnon/win32/win_iconbutton.c"

#include "../nonnon/project/macro.c"




#define H_BTN_L hgui[ 0 ]
#define H_BTN_M hgui[ 1 ]
#define H_BTN_R hgui[ 2 ]
#define GUI_MAX       3




LRESULT CALLBACK
n_applet_popup_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND  hgui[ GUI_MAX ];

	static HICON icon_ie, icon_cpl;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_L );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_M );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_R );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		n_win_gui_literal( hwnd, FICOBTN, "",  &H_BTN_L );
		n_win_gui_literal( hwnd, FICOBTN, "",  &H_BTN_M );
		n_win_gui_literal( hwnd, FICOBTN, "",  &H_BTN_R );


		n_win_icon_add_literal( H_BTN_R, "./n_applet.exe", 1 );


		// Style

		n_win_style_new( hwnd, WS_POPUP );
		n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );


		icon_ie  = n_ie_icon();
		icon_cpl = n_ie_icon_controlpanel();

		n_win_icon_set( H_BTN_L, icon_ie  );
		n_win_icon_set( H_BTN_M, icon_cpl );

		n_win_iconbutton_init( hwnd, H_BTN_L );
		n_win_iconbutton_init( hwnd, H_BTN_M );
		n_win_iconbutton_init( hwnd, H_BTN_R );


		// Size

		{

		const bool redraw = false;


		s32 ico,m;
		s32 csx,csy;


		n_win_stdsize( hwnd, NULL, &ico, &m );

		ico = ico + ( m * 2 );
		csx = ico * GUI_MAX;
		csy = ico;

		n_win_popup_automove( hwnd, csx,csy );

		n_win_move_simple( H_BTN_L, 0*ico,0, ico,ico, redraw );
		n_win_move_simple( H_BTN_M, 1*ico,0, ico,ico, redraw );
		n_win_move_simple( H_BTN_R, 2*ico,0, ico,ico, redraw );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_BTN_L )
		{

			n_ie_call();

		} else
		if ( h == H_BTN_M )
		{

			n_posix_char *inetcpl = n_posix_literal( "rundll32 shell32.dll,Control_RunDLL inetcpl.cpl,,1" );

			n_win_exec( inetcpl, SW_NORMAL );

		} else
		if ( h == H_BTN_R )
		{

			n_inetcpl_extremehigh();

			break;

		}

		n_win_message_send( hwnd, WM_CLOSE, 0,0 );

	}
	break;


	case WM_CLOSE :

		n_win_iconbutton_exit( hwnd, H_BTN_L );
		n_win_iconbutton_exit( hwnd, H_BTN_M );
		n_win_iconbutton_exit( hwnd, H_BTN_R );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		if ( sticky ) { break; }

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_L );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_M );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_R );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef GUI_MAX
#undef H_BTN_L
#undef H_BTN_M
#undef H_BTN_R

