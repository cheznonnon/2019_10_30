// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : default mode
//
//	1 : compressed with UPX
//	2 : pack as ZIP
//	3 : unpack ZIP'ed archive
//	4 : size will be unpacked too
//
//	for example
//	1 : 100KB =>  50KB
//	2 :  50KB =>  40KB
//	3 :  40KB => 100KB
//	4 : !!!
//
//	[ solution ]
//
// 	use "--lzma"


// [x] : icons will be compressed
//
//	[ solution ]
//
//	use "--compress-icons=0"




#include "../nonnon/neutral/path.c"

#include "../nonnon/win32/win/commandline.c"




void
n_upx_pack_file( n_posix_char *file )
{

	if ( false == n_path_ext_is_same_literal( ".exe", file ) ) { return; }


	const n_posix_char *upx = n_posix_literal( "Z:\\c\\__project\\upx.exe" );

	n_posix_char exe[ N_PATH_MAX ];
	n_posix_sprintf_literal( exe, "%s -qqq --compress-icons=0 --lzma %s%s%s", upx, N_STRING_DQUOTE, file, N_STRING_DQUOTE );
//n_posix_debug_literal( "%s", exe );

	n_win_execute( exe, SW_HIDE, true );


	return;
}

void
n_upx_pack_folder( n_posix_char *folder )
{

	n_posix_DIR *dp = n_posix_opendir_nodot( folder );
	if ( dp == NULL ) { return; }

	while( 1 )
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }

		n_posix_char abspath[ N_PATH_MAX ];
		n_path_maker( folder, dirent->d_name, abspath );

		n_upx_pack_file( abspath );

	}

	n_posix_closedir( dp );


	return;
}

int
main( void )
{

	n_posix_char cmdline[ N_PATH_MAX ];


	n_win_exedir2curdir();
	n_win_commandline( cmdline );


	if ( n_posix_stat_is_file( cmdline ) )
	{
		n_upx_pack_file  ( cmdline );
	} else {
		n_upx_pack_folder( cmdline );
	}


	return 0;
}

