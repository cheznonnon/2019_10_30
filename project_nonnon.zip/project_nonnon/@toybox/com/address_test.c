// Nonnon COM
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link
//
//	-lole32		COM base system
//	-loleaut32	oleauto.h : BSTR




#include <stdio.h>

#include <windows.h>

#include <exdisp.h>




int
main( int argc, char *argv[] )
{

	const GUID IID_IDispatch          = { 0x00020400,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
	const GUID CLSID_InternetExplorer = { 0x0002DF01,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
	const GUID IID_IWebBrowser2       = { 0xD30C1661,0xCDAF,0x11D0,{ 0x8A,0x3E, 0x00,0xC0,0x4F,0xC9,0xE2,0x6E } };


	IDispatch    *d1, *d2;
	IWebBrowser2 *ie;


	CoInitialize( NULL );


	CoCreateInstance( &CLSID_InternetExplorer, NULL, CLSCTX_ALL, &IID_IWebBrowser2, (void*) &ie );
	CoCreateInstance( &CLSID_InternetExplorer, NULL, CLSCTX_ALL, &IID_IWebBrowser2, (void*) &d1 );

	ie->lpVtbl->QueryInterface( ie, &IID_IDispatch, (void*) &d2 );


{

	char str[1024];

	long *p1 = (long*) ie->lpVtbl;
	long *p2 = (long*) d1->lpVtbl;
	long *p3 = (long*) d2->lpVtbl;


	sprintf(
		str,

		"Pointer \t IWebBrowser2 \t %d \n"
		"Pointer \t IDispatch1   \t %d \n"
		"Pointer \t IDispatch2   \t %d \n"
		"\n"
		"lpVtbl  \t IWebBrowser2 \t %d \n"
		"lpVtbl  \t IDispatch1   \t %d \n"
		"lpVtbl  \t IDispatch2   \t %d \n"
		"\n"
		"AddRef  \t IWebBrowser2 \t %d \n"
		"AddRef  \t IDispatch1   \t %d \n"
		"AddRef  \t IDispatch2   \t %d \n"
		"\n"
		"p1[1]   \t IWebBrowser2 \t %d \n"
		"p2[1]   \t IDispatch1   \t %d \n"
		"p3[1]   \t IDispatch2   \t %d \n"
		"\n"
		"void**  \t IWebBrowser2 \t %d \n"
		"void**  \t IDispatch1   \t %d \n"
		"void**  \t IDispatch2   \t %d \n",

		(int) ie,
		(int) d1,
		(int) d2,

		(int) ie->lpVtbl,
		(int) d1->lpVtbl,
		(int) d2->lpVtbl,

		(int) ie->lpVtbl->AddRef,
		(int) d1->lpVtbl->AddRef,
		(int) d2->lpVtbl->AddRef,

		(int) p1[ 1 ],
		(int) p2[ 1 ],
		(int) p3[ 1 ],

		(int) ( (void**) ie->lpVtbl )[ 1 ],
		(int) ( (void**) d1->lpVtbl )[ 1 ],
		(int) ( (void**) d2->lpVtbl )[ 1 ]
	);


	MessageBox( NULL, str, "DEBUG", 0 );

}


	ie->lpVtbl->Release( ie );
	d1->lpVtbl->Release( d1 );
	d2->lpVtbl->Release( d2 );


	CoUninitialize();


	return 0;
}

